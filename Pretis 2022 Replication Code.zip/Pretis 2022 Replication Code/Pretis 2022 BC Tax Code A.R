##############################################
################ Replication code (File A)
# Pretis (2022)
# "Does a carbon tax reduce CO2 emissions? Evidence from British Columbia"
# Environmental and Resource Economics, 83, 115-144
###############################################

###########
#### Code File A Replicates Main Model Estimates (non-gridded data)
##########


rm(list=ls())

#Set the working directory here
setwd('C:/Users/fpretis/OneDrive - University of Victoria/Documents/Projects/BC carbon tax/code/Pretis 2022 Replication Code')

library(gets)
library(plm)
library(dplyr)
library(plyr)
library(clusterSEs)
library(stargazer)
library(lmtest)
library(msm)
library(lfe)
library(dummies)
library(getspanel)
library(gtools)
library(htmlTable)
library(RColorBrewer)
library(plyr)
library(Synth)
library(devtools)
#install_github("bcastanho/SCtools")
library(SCtools)



# load Emissions data
dat <- read.csv("./data/GHG_IPCC_Can_Prov_Terr.csv", stringsAsFactors = FALSE)

dat$CO2.num <- as.numeric(dat$CO2)
dat$Region[dat$Region=="British Columbia"] <- "bc"
dat$Region[dat$Region=="Alberta"] <- "ab"
dat$Region[dat$Region=="Saskatchewan"] <- "sk"
dat$Region[dat$Region=="Manitoba"] <- "mb"
dat$Region[dat$Region=="Ontario"] <- "on"
dat$Region[dat$Region=="Quebec"] <- "qc"
dat$Region[dat$Region=="Newfoundland and Labrador"] <- "nl"
dat$Region[dat$Region=="New Brunswick"] <- "nb"
dat$Region[dat$Region=="Nova Scotia"] <- "ns"
dat$Region[dat$Region=="Prince Edward Island"] <- "pe"

dats <- dat[dat$Region %in% c("bc", "ab", "sk", "mb", "on", "qc", "nl", "nb", "ns", "pe"),]

relcats <- c("TOTAL", 
             "Stationary Combustion Sources", 
             "Transport", 
             "Fugitive Sources",
             "AGRICULTURE",  
             "INDUSTRIAL PROCESSES AND PRODUCT USE", 
             "WASTE")

dats <- dats[dats$Category %in% relcats,]
dats <- dats[, c("Year", "Region", "Category", "CO2.num")]
names(dats) <- c("year", "prov", "cat", "co2")

dats.wide <- reshape(dats, idvar = c("prov", "year"), timevar = "cat", direction = "wide")
dats.wide
#################

#######################################
################ Sector Level Analysis
#######################################

datprov <- dats.wide
  
###########


datprov <- datprov[!datprov$prov=="yt",] #drop Yukon Territory (analysis focuses on Provinces)

drop_ab_qc <- FALSE #User Choice: drop Alberta and Quebec from control group if TRUE, default is FALSE

if (drop_ab_qc==TRUE){
  
  datprov <- datprov[!datprov$prov %in% c("ab", "qc"),]
  
}

drop_on <- FALSE #User Choice: drop Ontario from control group if TRUE, default is FALSE

if (drop_on==TRUE){
  
  datprov <- datprov[!datprov$prov %in% c("on"),]
  
}

clusreps <- 499 #cluster robust bootstrap replications


###########
nprov <- length(unique(datprov$prov))
cat <- names(datprov)[3:NCOL(datprov)]
ncat <- NROW(cat)


cat.results <- data.frame(matrix(NA, nrow=ncat, ncol=15))
names(cat.results) <- c("cat", "dcoef", "dse", "lcoef", "lse", "dcoef.imp", "dse.imp", "lcoef.imp", "lse.imp", "dcoef.L1", "dse.L1", "lcoef.L1", "lse.L1", "dcoef.imp.L1", "dse.imp.L1")

cat.results$lci.L1.clus.upper <- NA
cat.results$lci.L1.clus.lower <- NA

cat.results$lci.L1.clus.upper99 <- NA
cat.results$lci.L1.clus.lower99 <- NA

cat.results$lcoef.L1.imed <- NA
cat.results$lcoef.L1.imed.se <- NA

cat.results$lcoef.L1.ar <- NA
cat.results$lcoef.L1.ar.se <- NA
##### store models for results tables
sec.level.model.list <- list()
sec.level.model.se.list <- list()

#####
sec.level.dollar.model.list <- list()
sec.level.dollar.model.se.list <- list()

#### dummy for tax increase
sec.level.model.incr.list <- list()
sec.level.model.incr.se.list <- list()

#### differences
sec.diff.model.list <- list()
sec.diff.model.se.list <- list()

#### parallel trend estimates
pretrend.level.model.list <- list()
pretrend.level.se.list <- list()

###### additional lag models
sec.level.model.lag.list <- list()
sec.level.model.lag.se.list <- list()

sec.level.model.lag.indep.list <- list()
sec.level.model.lag.indep.se.list <- list()


####synthetic control
synth.msp <- data.frame(matrix(NA, nrow=ncat, ncol=2)) #ratio$p.val
names(synth.msp) <- c("cat", "p.val")
synth.msp$cat <- cat

synth.gap <- data.frame(matrix(NA, nrow=26, ncol=(ncat+1)))
names(synth.gap) <- c("year", cat)
synth.gap$year <- seq(from=1991, to=2016, by=1)

dat.list <- list()


############ Main Estimation Loop. Loops over each sector and generates estimates:
for (j in 1:ncat){
  #j <- 1
  cat.j <- cat[j]
  print(cat.j)
  
  cat.results$cat[j] <- cat.j
  
  relvars <- c("year", "prov", cat.j)
  
  dat <- datprov[relvars]
  names(dat) <- c("year", "prov", "emiss")
  
  #### adjust logs of zero values
  dat$emiss[which(dat$emiss==0)] <- dat$emiss[which(dat$emiss==0)] + 1 
  
#######################################################

#Create Binary Treatment Variable for BC  
dat$bc_tax <- 0
dat$L1.bc_tax <- 0
dat$L2.bc_tax <- 0
dat$L3.bc_tax <- 0

dat$bc_tax[dat$prov=="bc" & dat$year >= 2008] <- 1
dat$L1.bc_tax[dat$prov=="bc" & dat$year >= 2009] <- 1
dat$L2.bc_tax[dat$prov=="bc" & dat$year >= 2010] <- 1
dat$L3.bc_tax[dat$prov=="bc" & dat$year >= 2011] <- 1

dat$bc_tax_dum <- 0
dat$L1.bc_tax_dum <- 0
dat$bc_tax_dum[dat$prov=="bc" & dat$year == 2008] <- 1
dat$L1.bc_tax_dum[dat$prov=="bc" & dat$year == 2009] <- 1

dat$bc_tax_val <- 0
dat$bc_tax_val[dat$prov=="bc" & dat$year == 2008] <- 10 
dat$bc_tax_val[dat$prov=="bc" & dat$year == 2009] <- 15 
dat$bc_tax_val[dat$prov=="bc" & dat$year == 2010] <- 20 
dat$bc_tax_val[dat$prov=="bc" & dat$year == 2011] <- 25 
dat$bc_tax_val[dat$prov=="bc" & dat$year >= 2012] <- 30 

dat$bc_2000 <- 0
dat$bc_2000[dat$prov=="bc" & dat$year > 2000] <- 1

## binary variables for magnitudes of tax changes
dat$bc_r15 <- 0
dat$bc_r20 <- 0
dat$bc_r25 <- 0
dat$bc_r30 <- 0

dat$bc_r15[dat$prov=="bc" & dat$year >= 2009] <- 1 
dat$bc_r20[dat$prov=="bc" & dat$year >= 2010] <- 1 
dat$bc_r25[dat$prov=="bc" & dat$year >= 2011] <- 1 
dat$bc_r30[dat$prov=="bc" & dat$year >= 2012] <- 1 

###### lead lag of bc tax

### lag
dat$bc_tax_p1 <- dat$bc_r15
dat$bc_tax_p2 <- dat$bc_r20
dat$bc_tax_p3 <- dat$bc_r25
dat$bc_tax_p4 <- dat$bc_r30

### lead
dat$bc_tax_m1 <- 0
dat$bc_tax_m2 <- 0
dat$bc_tax_m3 <- 0
dat$bc_tax_m4 <- 0

dat$bc_tax_m4[dat$prov=="bc" & dat$year >= 2004] <- 1 
dat$bc_tax_m3[dat$prov=="bc" & dat$year >= 2005] <- 1 
dat$bc_tax_m2[dat$prov=="bc" & dat$year >= 2006] <- 1 
dat$bc_tax_m1[dat$prov=="bc" & dat$year >= 2007] <- 1 
####################


dat$prov <- as.factor(dat$prov)
dat$prov.id <- as.numeric(dat$prov)
################################################

## Load population data
pop <- read.csv("./data/can_population_prov.csv")
pop$prov <- as.factor(pop$prov)
datm <- merge(dat, pop, by=c("year", "prov"))
datm <- datm[order(datm$prov.id, datm$year),]

## Load gdp data
gdp <-  read.csv("./data/can_gdp.csv")
gdp <- gdp[,c(1,2, NCOL(gdp))]
datm <- merge(datm, gdp, by=c("year", "prov"))
datm <- datm[order(datm$prov.id, datm$year),]


datm$emiss_pc <- datm$emiss/datm$pop
datm$Lemiss_pc <- log(datm$emiss_pc)

datm$Lpop <- log(datm$pop)
datm$Lemiss <- log(datm$emiss)
datm$Lgdp <- log(datm$gdp_marketpr)

###order the data to construct lags
datm <- datm[order(datm$prov, datm$year),]

lg <- function(x)c(NA, x[1:(length(x)-1)])
library(plyr)

datm <- ddply(datm, ~prov, transform, L1.emiss_pc = lg(emiss_pc))
datm <- ddply(datm, ~prov, transform, L1.Lemiss_pc = lg(Lemiss_pc))

datm <- ddply(datm, ~prov, transform, L1.emiss = lg(emiss))
datm <- ddply(datm, ~prov, transform, L1.Lemiss = lg(Lemiss))

datm <- ddply(datm, ~prov, transform, L2.Lemiss = lg(L1.Lemiss))
datm <- ddply(datm, ~prov, transform, L3.Lemiss = lg(L2.Lemiss))

datm <- ddply(datm, ~prov, transform, L1.Lpop = lg(Lpop))
datm <- ddply(datm, ~prov, transform, L1.Lgdp = lg(Lgdp))

datm$dLemiss_pc <- datm$Lemiss_pc - datm$L1.Lemiss_pc
datm$dLemiss <- datm$Lemiss - datm$L1.Lemiss
datm$dLpop <- datm$Lpop - datm$L1.Lpop
datm$dLgdp <- datm$Lgdp - datm$L1.Lgdp

datm <- ddply(datm, ~prov, transform, L1.dLemiss_pc = lg(dLemiss_pc))
datm <- ddply(datm, ~prov, transform, L1.dLemiss = lg(dLemiss))

datm$demiss_pc <- datm$emiss_pc - datm$L1.emiss_pc

datm <- ddply(datm, ~prov, transform, L1.bc_tax_dum = lg(bc_tax_dum))

#######################################
############# On Levels
##############################################

dat.list[[j]] <- datm
names(dat.list)[j] <- cat.j

datm.mod <- datm[,c("prov", "year", "Lemiss", "bc_tax", "L1.Lemiss", "L2.Lemiss", "L3.Lemiss", "Lpop", "Lgdp", "L1.Lpop", "L1.Lgdp")]

##### Model without lags
m5.1m <- plm(Lemiss ~ bc_tax + Lpop +Lgdp, data=datm.mod, effect="twoways", index=c( "prov", "year"), model="within")
summary(m5.1m)

coefs5.1 <- coeftest(m5.1m, vcov=vcovHC(m5.1m,type="HC0",cluster="group"))

lcoef <- coefs5.1[1,1]
lse <- coefs5.1[1,2]

cat.results$lcoef[j] <- lcoef
cat.results$lse[j] <- lse

datm.mod.num <- datm.mod
datm.mod.num$prov <- as.numeric(datm.mod$prov)

#Store Dataset for particular sectors (for convenience)
csv_name <- paste("./data/generated/ere_emissions_", cat.j, ".csv", sep="")
write.csv(datm.mod.num, csv_name, row.names = FALSE)


##### Model with lag
m5.2m <- plm(Lemiss ~ bc_tax + L1.Lemiss + Lpop +Lgdp, data=datm.mod, effect="twoways", index=c( "prov", "year"), model="within")
summary(m5.2m)

m5.2m.vcm <- pvcm(Lemiss ~ bc_tax + L1.Lemiss + Lpop +Lgdp, data=datm.mod, effect="individual", index=c( "prov", "year"), model="within")


###pooling with interactions

m5.2m.lfe <- felm(Lemiss ~ bc_tax + L1.Lemiss + Lpop +Lgdp | prov + year | 0 | 0, data=datm.mod)
summary(m5.2m.lfe)

m5.2m.lfe.prov <- felm(Lemiss ~ bc_tax + L1.Lemiss + Lpop + Lpop:prov + Lgdp+Lgdp:prov | prov + year | 0 | 0, data=datm.mod)
summary(m5.2m.lfe.prov)

# waldtest(m5.2m.lfe.prov, ~ `Lpop:provbc`| `Lpop:provmb` | `Lpop:provnb` | `Lpop:provnl` |`Lpop:provns`| 
#            `Lpop:provon` |`Lpop:provpe`|`Lpop:provqc`| `Lpop:provsk`| `provbc:Lgdp`|
#            `provmb:Lgdp`| `provnb:Lgdp`| `provnl:Lgdp`| `provns:Lgdp`| `provon:Lgdp`| 
#            `provpe:Lgdp`| `provqc:Lgdp`| `provsk:Lgdp`, type="iid" )
# 
# coefficients(m5.2m.lfe.prov)


#####Model with multiple lags of dependent variable

m5.2m.lags <- plm(Lemiss ~ bc_tax + L1.Lemiss + L2.Lemiss  + L3.Lemiss + Lpop +Lgdp, data=datm.mod, effect="twoways", index=c( "prov", "year"), model="within")
summary(m5.2m.lags)

coefs5.2.lags <- coeftest(m5.2m.lags, vcov=vcovHC(m5.2m.lags,type="HC0",cluster="group"))


####Model with lags of dep and indep (for difference effects)
m5.2m.lagsindep <- plm(Lemiss ~ bc_tax + L1.Lemiss    + Lpop + L1.Lpop +Lgdp +L1.Lgdp, data=datm.mod, effect="twoways", index=c( "prov", "year"), model="within")
summary(m5.2m.lagsindep)

coefs5.2.lags.indep <- coeftest(m5.2m.lagsindep, vcov=vcovHC(m5.2m.lagsindep,type="HC0",cluster="group"))

sec.level.model.lag.list[[j]] <- m5.2m.lags
sec.level.model.lag.se.list[[j]] <- coefs5.2.lags

sec.level.model.lag.indep.list[[j]] <- m5.2m.lagsindep
sec.level.model.lag.indep.se.list[[j]] <- coefs5.2.lags.indep


#####################################

### Compute Equilibrium Effects (accounting for autoregressive lag)

relcoef5.2 <- coefficients(m5.2m)[c("bc_tax", "L1.Lemiss")]
vcov5.2 <- vcovHC(m5.2m,type="HC0",cluster="group")[c("bc_tax", "L1.Lemiss"),c("bc_tax", "L1.Lemiss")]
coefs5.2 <- coeftest(m5.2m, vcov=vcovHC(m5.2m,type="HC0",cluster="group"))

taxeqbm5.2 <- relcoef5.2[1]/(1-relcoef5.2[2])
taxeqbm5.2.se <- deltamethod(~ x1/(1-x2), relcoef5.2, vcov5.2) 

lcoef.L1 <- taxeqbm5.2
lse.L1 <- taxeqbm5.2.se

cat.results$lcoef.L1[j] <- lcoef.L1
cat.results$lse.L1[j] <- lse.L1

cat.results$lcoef.L1.imed[j] <- coefs5.2['bc_tax',1]
cat.results$lcoef.L1.imed.se[j] <- coefs5.2['bc_tax',2]

cat.results$lcoef.L1.ar[j] <- coefs5.2['L1.Lemiss',1]
cat.results$lcoef.L1.ar.se[j] <- coefs5.2['L1.Lemiss',2]

m.res <- list(m5.2m, coefs5.2)
names(m.res) <- c("model", "coefs")

#########
## Store Model for Later Printing
sec.level.model.list[[j]] <- m5.2m
sec.level.model.se.list[[j]] <- coefs5.2


##############
### Models with price dummies
##########

### with dummies for introduction of tax and then price increases
datm.mod.r <- datm[,c("prov", "year", "Lemiss", "bc_tax", "L1.Lemiss", "Lpop", "Lgdp", "bc_r15", "bc_r20", "bc_r25", "bc_r30")]

m5.2m.r <- plm(Lemiss ~ bc_tax  + bc_r15 + bc_r20 + bc_r25 + bc_r30 + L1.Lemiss + Lpop +Lgdp, data=datm.mod.r, effect="twoways", index=c( "prov", "year"), model="within")
summary(m5.2m.r)

coefs5.2.r <- coeftest(m5.2m.r, vcov=vcovHC(m5.2m.r,type="HC0",cluster="group"))
coefs5.2.r

sec.level.model.incr.list[[j]] <- m5.2m.r
sec.level.model.incr.se.list[[j]] <- coefs5.2.r

##### model in differences
m4.1.d <- plm(dLemiss ~ bc_tax + dLpop + dLgdp, data=datm, effect="twoways", index=c( "prov", "year"), model="within")
summary(m4.1.d)
coefs4.1.d <- coeftest(m4.1.d, vcov=vcovHC(m4.1.d,type="HC0",cluster="group"))

m4.1.d.imp <- plm(dLemiss ~ bc_tax_dum + dLpop + dLgdp, data=datm, effect="twoways", index=c( "prov", "year"), model="within")
summary(m4.1.d.imp)
coefs4.1.dum <- coeftest(m4.1.d.imp, vcov=vcovHC(m4.1.d.imp,type="HC0",cluster="group"))

sec.diff.model.list[[j]] <- m4.1.d
sec.diff.model.se.list[[j]] <- coefs4.1.d
#########

##############
### Model with lead and lag dummies
##########

  ############ Pre-Trends Assessment:
  ### with dummies for introduction of tax and then price increases
  datm.mod.r <- datm[,c("prov", "year", "Lemiss", "bc_tax", "L1.Lemiss", "Lpop", "Lgdp",  "bc_tax_p1", "bc_tax_p2", "bc_tax_p3", "bc_tax_p4", "bc_tax_m1", "bc_tax_m2", "bc_tax_m3", "bc_tax_m4")]
  
  m5.2m.r <- plm(Lemiss ~      bc_tax_m2 + bc_tax_m1 + bc_tax   + L1.Lemiss + Lpop +Lgdp, data=datm.mod.r, effect="twoways", index=c( "prov", "year"), model="within")
  
  coefs5.2.r <- coeftest(m5.2m.r, vcov=vcovHC(m5.2m.r,type="HC0",cluster="group"))

  pretrend.level.model.list[[j]] <- m5.2m.r
  pretrend.level.se.list[[j]] <- coefs5.2.r
  
  
## Computer Cluster Wild Bootstrap
source("cluster_functions.R")

clus.se <- cluster.wild.plm(m5.2m, datm.mod, cluster="group", ci.level = 0.95, boot.reps = clusreps, report = TRUE, prog.bar = TRUE)

cat.results$lci.L1.clus.upper[j] <- clus.se$ci["bc_tax",2]
cat.results$lci.L1.clus.lower[j] <- clus.se$ci["bc_tax",1]

########################################
####cluster robust for model with dummies for pre-trends
clus.se.r <- cluster.wild.plm(m5.2m.r, datm.mod.r, cluster="group", ci.level = 0.95, boot.reps = clusreps, report = TRUE, prog.bar = TRUE)
clus.se.r




########################################
############### Randomisation Inference
##########################################

#########################################
#### assign treatment to all other potential timing and control groups
############

datm.mod$ran_coef_tax <- NA
datm.mod$ran_t_tax <- NA
datm.mod$ran_coef_tax_eqbm <- NA
datm.mod$ran_t_tax_eqbm <- NA


for (m in 1:(NROW(datm.mod)-sum(datm.mod$bc_tax))){
  #print(m)

  datm.mod$bc_tax_i <- 0
  datm.mod$bc_tax_i[m:(m+sum(datm.mod$bc_tax))] <- 1
  
  m5.2m_i <- plm(Lemiss ~ bc_tax_i + L1.Lemiss + Lpop +Lgdp, data=datm.mod, effect="twoways", index=c( "prov", "year"), model="within")

  relcoef5.2_i <- coefficients(m5.2m_i)[c("bc_tax_i", "L1.Lemiss")]
  vcov5.2_i <- vcovHC(m5.2m_i,type="HC0",cluster="group")[c("bc_tax_i", "L1.Lemiss"),c("bc_tax_i", "L1.Lemiss")]
  coefs5.2_i <- coeftest(m5.2m_i, vcov=vcovHC(m5.2m_i,type="HC0",cluster="group"))
  
  taxeqbm5.2_i <- relcoef5.2_i[1]/(1-relcoef5.2_i[2])
  taxeqbm5.2.se_i <- deltamethod(~ x1/(1-x2), relcoef5.2_i, vcov5.2_i) 

  datm.mod$ran_coef_tax[m] <- coefs5.2_i[c("bc_tax_i"),1]
  datm.mod$ran_t_tax[m] <- coefs5.2_i[c("bc_tax_i"),3]
  
  datm.mod$ran_coef_tax_eqbm[m] <- taxeqbm5.2_i
  datm.mod$ran_t_tax_eqbm[m] <- taxeqbm5.2_i/taxeqbm5.2.se_i
  
}

datm.mod$ran_coef_tax[datm.mod$prov=="bc"] <- NA
datm.mod$ran_t_tax[datm.mod$prov=="bc"] <- NA
datm.mod$ran_coef_tax_eqbm[datm.mod$prov=="bc"] <- NA
datm.mod$ran_t_tax_eqbm[datm.mod$prov=="bc"] <- NA


coef.p <-  2*(1-ecdf(datm.mod$ran_coef_tax)(abs(relcoef5.2[1])))
t.p <-  2*(1-ecdf(datm.mod$ran_t_tax)(abs(coefs5.2["bc_tax", 3]))) 

random_quants_coef <- quantile(datm.mod$ran_coef_tax, prob=c(0.025, 0.975), na.rm=TRUE)
random_quants_t <- quantile(datm.mod$ran_t_tax, prob=c(0.025, 0.975), na.rm=TRUE)

random_quants_coef_05 <- quantile(datm.mod$ran_coef_tax, prob=c(0.05, 0.95), na.rm=TRUE)
random_quants_t_05 <- quantile(datm.mod$ran_t_tax, prob=c(0.05, 0.95), na.rm=TRUE)

random_inf_name <- paste("./figures/Figure_5_random_inf_", cat.j,   "_ab_qc", drop_ab_qc, ".pdf", sep="")

pdf(random_inf_name, width=13, height=7)

par(mfrow=c(1,2))
hist(datm.mod$ran_coef_tax, main= paste(cat.j, ": Tax Coefficient", sep=""),  xlab="Coefficient", breaks=12)
abline(v=relcoef5.2[1], col="#a50f15", lwd=3)
text(label=paste("Emp. p-value: ", round(coef.p, 2), sep=""), x=-0.07, y=30)
abline(v=random_quants_coef, col="gray35", lwd=2, lty=2)
abline(v=random_quants_coef_05, col="gray35", lwd=2, lty=3)


hist(datm.mod$ran_t_tax, main= paste(cat.j, ": Tax t-Statistic", sep=""),   xlab="t-value", breaks=12)
abline(v=coefs5.2["bc_tax", 3], col="#a50f15", lwd=3)
text(label=paste("Emp. p-value: ", round(t.p, 2), sep=""), x=5, y=50)
abline(v=random_quants_t, col="gray35", lwd=2, lty=2)
abline(v=random_quants_t_05, col="gray35", lwd=2, lty=3)


dev.off()

#############################################
#############################################
  
if (j %in% c(1)){
    
############################## Full sample but drop provinces for robustness analysis  
###drop ontario and ab, qc  
datm.mod.sub1 <- datm.mod[!datprov$prov %in% c("ab", "qc", "on"),]
m5.1m <- plm(Lemiss ~ bc_tax + Lpop +Lgdp, data=datm.mod.sub1, effect="twoways", index=c( "prov", "year"), model="within")
summary(m5.1m)
coefs5.1 <- coeftest(m5.1m, vcov=vcovHC(m5.1m,type="HC0",cluster="group"))
coefs5.1

### modify with lag
m5.1m.f <- plm(Lemiss ~ bc_tax + L1.Lemiss  + Lpop +Lgdp, data=datm.mod.sub1, effect="twoways", index=c( "prov", "year"), model="within")
summary(m5.1m.f)
coefs5.1.f <- coeftest(m5.1m.f, vcov=vcovHC(m5.1m.f,type="HC0",cluster="group"))
coefs5.1.f

### modify with cluster robust ses
clus.se.nolag.m5.1m <- cluster.wild.plm(m5.1m, datm.mod.sub1, cluster="group", ci.level = 0.95, boot.reps = clusreps, report = TRUE, prog.bar = TRUE)
clus.se.nolag.m5.1m

###with cluster ses and lag
clus.se.m5.1m.f <- cluster.wild.plm(m5.1m.f, datm.mod.sub1, cluster="group", ci.level = 0.95, boot.reps = clusreps, report = TRUE, prog.bar = TRUE)
clus.se.m5.1m.f

####################################################
################## Timing Subsample
####drop 1990 to 1995
datm.mod.sub2 <- datm.mod.sub1[datm.mod.sub1$year >1994,]
m5.2m <- plm(Lemiss ~ bc_tax + Lpop +Lgdp, data=datm.mod.sub2, effect="twoways", index=c( "prov", "year"), model="within")
summary(m5.2m)
coefs5.2 <- coeftest(m5.2m, vcov=vcovHC(m5.1m,type="HC0",cluster="group"))
coefs5.2

### modify with lag
m5.2m.f <- plm(Lemiss ~ bc_tax + L1.Lemiss  + Lpop +Lgdp, data=datm.mod.sub2, effect="twoways", index=c( "prov", "year"), model="within")
summary(m5.2m.f)
coefs5.2.f <- coeftest(m5.2m.f, vcov=vcovHC(m5.2m.f,type="HC0",cluster="group"))
coefs5.2.f

### modify with cluster robust ses
clus.se.nolag.m5.2m <- cluster.wild.plm(m5.2m, datm.mod.sub2, cluster="group", ci.level = 0.95, boot.reps = clusreps, report = TRUE, prog.bar = TRUE)
clus.se.nolag.m5.2m

###with cluster ses and lag
clus.se.m5.2m.f <- cluster.wild.plm(m5.2m.f, datm.mod.sub2, cluster="group", ci.level = 0.95, boot.reps = clusreps, report = TRUE, prog.bar = TRUE)
clus.se.m5.2m.f
###########################################
############################################

sec.level.model.list.met <- list(m5.1m, m5.1m, m5.1m.f, m5.1m.f, m5.2m, m5.2m, m5.2m.f,  m5.2m.f)
se.list.met <- list(coefs5.1[,2], coefs5.1.f[,2], coefs5.2[,2], coefs5.2.f[,2])
p.list.met <- list(coefs5.1[,4], clus.se.nolag.m5.1m[[1]], coefs5.1.f[,4], clus.se.m5.1m.f[[1]], coefs5.2[,4], clus.se.nolag.m5.2m[[1]], coefs5.2.f[,4], clus.se.m5.2m.f[[1]])

  
col.labs <- c("Static", "Static Boot.", "Dyn.", "Dyn. Boot.", "Static (1996-)", "Static (1995-) Boot.", "Dyn. (1995-)", "Dyn. (1995-) Boot.")
covar.labs <- c("Carbon Tax", "logEmiss.L1", "logPop", "logGDP")


lev_name <- paste("./tables/Table_E1_metcalf.doc", sep="")

names(sec.level.model.list.met) <- c("Static", "Static (B)", "Dyn.", "Dyn. (B)", "Static (1995-)", "Static (1995-) (B)", "Dyn. (1995-)", "Dyn. (1995-) (B)")

names(sec.level.model.list.met)

stargazer( sec.level.model.list.met, se=NULL, ci=FALSE, p=p.list.met, type="html", out=lev_name,  covariate.labels=covar.labs,
           dep.var.labels="logEmiss", star.char = c(".", "*", "**", "***"),
           star.cutoffs = c(0.1, 0.05, 0.01, 0.001), report=('vc*p'), 
           column.labels = col.labs,
           notes = c(". p<0.1; * p<0.05; ** p<0.01; *** p<0.001"), table.layout = "=ldc-t-s-n", keep.stat=c("rsq", "f", "ll", "sigma2", "n"))


}
##################################

###### with dollar value of tax
m5.1m.val <- plm(Lemiss ~ bc_tax_val + L1.Lemiss + Lpop +Lgdp, data=datm, effect="twoways", index=c( "prov", "year"), model="within")
summary(m5.1m.val)
coefs5.1.val <- coeftest(m5.1m.val, vcov=vcovHC(m5.1m.val,type="HC0",cluster="group"))
coefs5.1.val


clus.se.m5.1m.val <- cluster.wild.plm(m5.1m.val, datm, cluster="group", ci.level = 0.95, boot.reps = clusreps, report = TRUE, prog.bar = TRUE)
clus.se.m5.1m.val

###with logs
datm$bc_tax_val2 <- datm$bc_tax_val + 1
datm$lbc_tax_val2 <- log(datm$bc_tax_val2)

m5.1m.val2 <- plm(Lemiss ~ lbc_tax_val2 + L1.Lemiss + Lpop +Lgdp, data=datm, effect="twoways", index=c( "prov", "year"), model="within")
summary(m5.1m.val2)

#####################

datm$bc_tax_val

########################################
######## store dollar value regressions


sec.level.dollar.model.list[[j]] <- m5.1m.val
sec.level.dollar.model.se.list[[j]] <- coefs5.1.val


############################
#########################################


datm$prov.id
datm$prov.id[datm$prov=="bc"]
str(datm$prov.id)
str(datm$Lpop)
max(datm$year)
datm$provnames <- as.character(datm$prov)

dataprep.out <-
  dataprep(foo = datm,
           predictors = c("L1.Lemiss", "Lpop" , "Lgdp") ,
           predictors.op = "mean" ,
           time.predictors.prior = 1991:2007 ,
           special.predictors = NULL,
           dependent = "Lemiss",
           unit.variable = "prov.id",
           unit.names.variable = "provnames",
           time.variable = "year",
           treatment.identifier = 2,
           controls.identifier = c(1,3:10),
           time.optimize.ssr = 1991:2007,
           time.plot = 1991:2016
  )

synth.out <- synth(data.prep.obj = dataprep.out, method = "BFGS")

gaps <- dataprep.out$Y1plot - (dataprep.out$Y0plot %*% synth.out$solution.w)
gaps[1:3, 1]

synth.tables <- synth.tab(dataprep.res = dataprep.out,
                          synth.res = synth.out)
synth.tables
relsynth <- data.frame(synth.tables)[,4:6]
relsynth <- as.matrix(relsynth)

write.csv(relsynth, paste("./tables/Table_G1_synth_weights_", cat.j, ".csv", sep=""), row.names=FALSE)

synthname_1 <- paste("./figures/Figure_7_synth_", cat.j,   "_ab_qc", drop_ab_qc, ".pdf", sep="")
tax_col <- "#7570b3"

if (cat.j %in% c("co2.WASTE")){
  ylims <- c(3.5, 5)
}

if (cat.j %in% c("co2.Stationary Combustion Sources", "co2.Transport", "co2.TOTAL")){
  ylims <- c(9.2, 10.5)
}

if (cat.j %in% c("co2.TOTAL")){
  ylims <- c(10, 11.5)
}

if (cat.j %in% c("co2.Fugitive Sources", "co2.INDUSTRIAL PROCESSES AND PRODUCT USE")){
  ylims <- c(6.8, 8.5)
}

if (cat.j %in% c("co2.AGRICULTURE")){
  ylims <- c(2, 6)
}

pdf(synthname_1,width=12,height=7)

par(mfrow=c(1,2))

path.plot(synth.res = synth.out,
          dataprep.res = dataprep.out,
          Ylab = "Log CO2 Emissions",
          Xlab = "",
          Ylim = ylims,
          Legend = c("BC","Synthetic BC"),
          Legend.position = "topleft",
          Main = cat.j,  abline(v=2008, lty=2, lwd=1.2, col=tax_col))


gaps.plot(synth.res = synth.out,
          dataprep.res = dataprep.out,
          Ylab = "Gap in log CO2 Emissions",
          Xlab = "",
         # Ylim = c(-0.2,0.2),
          Main = cat.j,
          abline(v=2008, lty=2, lwd=1.2, col=tax_col))
dev.off()


###################
tdf<-generate.placebos(dataprep.out,synth.out)
ratio<-mspe.test(tdf, discard.extreme = FALSE)

###### store gap and p-value
synth.msp$p.val[j] <- ratio$p.val
synth.gap[,j+1] <- as.vector(gaps)

######## Placebo Test
store <- matrix(NA,length(1991:2016),10)
colnames(store) <- unique(datm$provnames)

for (iter in 1:10){
  
  print(iter)  
  dataprep.out_iter <-
    dataprep(foo = datm,
             predictors = c("L1.Lemiss", "Lpop" , "Lgdp") ,
             predictors.op = "mean" ,
             time.predictors.prior = 1991:2007 ,
             special.predictors = NULL,
             dependent = "Lemiss",
             unit.variable = "prov.id",
             unit.names.variable = "provnames",
             time.variable = "year",
             treatment.identifier = iter,
             controls.identifier = c(1:10)[-iter],
             time.optimize.ssr = 1991:2007,
             time.plot = 1991:2016
    )
  
  synth.out_iter <- synth(
    data.prep.obj = dataprep.out_iter,
    method = "BFGS"
  )
  
  # store gaps
  store[,iter] <- dataprep.out_iter$Y1plot - (dataprep.out_iter$Y0plot %*% synth.out_iter$solution.w)
  
}

data <- store
rownames(data) <- 1991:2016

# Set bounds in gaps data
gap.start     <- 1
gap.end       <- nrow(data)
years         <- 1991:2016
gap.end.pre  <- which(rownames(data)=="2007")

#  MSPE Pre-Treatment
mse        <-             apply(data[ gap.start:gap.end.pre,]^2,2,mean)
bc.mse <- as.numeric(mse[names(mse)=="bc"])
# Exclude states with 5 times higher MSPE than BC
if (cat.j=="co2.WASTE"){
  data <- data[,mse<10*bc.mse]

} else {
  data <- data[,mse<5*bc.mse]
}

Cex.set <- .75 


synthname_2 <- paste("./figures/Figure_7_synth_permut_", cat.j,   "_ab_qc", drop_ab_qc, ".pdf", sep="")
pdf(synthname_2,width=8,height=8)

par(mfrow=c(1,1))

# Plot
plot(years,data[gap.start:gap.end,which(colnames(data)=="bc")],
     ylim=c(1.15*min(data),1.15*max(data)),xlab="",
     xlim=c(1991,2016),ylab="Gap in log CO2 Emissions",
     type="l",lwd=2,col="black",
     xaxs="i",yaxs="i", main=cat.j)

# Add lines for control states
for (i in 1:ncol(data)) { lines(years,data[gap.start:gap.end,i],col="gray") }

## Add Basque Line
lines(years,data[gap.start:gap.end,which(colnames(data)=="bc")],lwd=2,col="black")

# Add grid
abline(v=2008,lty=2,lwd=1.2, col=tax_col)
abline(h=0,lty="dashed",lwd=2)
legend("topleft",legend=c("BC","control regions"),
       lty=c(1,1),col=c("black","gray"),lwd=c(2,1),cex=.8)
abline(v=1991)
abline(v=2016)
dev.off()

############ Create joint plot

synthname_1 <- paste("./figures/Figure_7_synth_comb_", cat.j,   "_ab_qc", drop_ab_qc, ".pdf", sep="")
tax_col <- "#7570b3"

if (cat.j %in% c("co2.WASTE")){
  ylims <- c(3.5, 5)
}

if (cat.j %in% c("co2.Stationary Combustion Sources", "co2.Transport", "co2.TOTAL")){
  ylims <- c(9.2, 10.5)
}

if (cat.j %in% c("co2.TOTAL")){
  ylims <- c(10, 11.5)
}

if (cat.j %in% c("co2.Fugitive Sources", "co2.INDUSTRIAL PROCESSES AND PRODUCT USE")){
  ylims <- c(6.8, 8.5)
}

if (cat.j %in% c("co2.AGRICULTURE")){
  ylims <- c(2, 6)
}

pdf(synthname_1,width=14,height=7)

par(mfrow=c(1,3))

path.plot(synth.res = synth.out,
          dataprep.res = dataprep.out,
          Ylab = "Log CO2 Emissions",
          Xlab = "",
          Ylim = ylims,
          Legend = c("BC","Synthetic BC"),
          Legend.position = "topleft",
          Main = cat.j,  abline(v=2008, lty=2, lwd=1.2, col=tax_col))


gaps.plot(synth.res = synth.out,
          dataprep.res = dataprep.out,
          Ylab = "Gap in log CO2 Emissions",
          Xlab = "",
          #Ylim = c(-0.4,0.4),
          Main = cat.j,
          abline(v=2008, lty=2, lwd=1.2, col=tax_col))
# Plot
plot(years,data[gap.start:gap.end,which(colnames(data)=="bc")],
     ylim=c(1.15*min(data),1.15*max(data)),xlab="",
     xlim=c(1991,2016),ylab="Gap in log CO2 Emissions",
     type="l",lwd=2,col="black",
     xaxs="i",yaxs="i", main=cat.j)

# Add lines for control states
for (i in 1:ncol(data)) { lines(years,data[gap.start:gap.end,i],col="gray") }

## Add Basque Line
lines(years,data[gap.start:gap.end,which(colnames(data)=="bc")],lwd=2,col="black")

# Add grid
abline(v=2008,lty=2,lwd=1.2, col=tax_col)
abline(h=0,lty="dashed",lwd=2)
legend("topleft",legend=c("BC","control regions"),
       lty=c(1,1),col=c("black","gray"),lwd=c(2,1),cex=.8)
#arrows(2008,-1.5,1968.5,-1.5,col=tax_col,length=.1)
#text(2008.5,-1.5,"Carbon Tax Introduced",cex=Cex.set)
abline(v=1991)
abline(v=2016)
dev.off()


##########################################
############ On Differences
##############################################


m4.1 <- plm(dLemiss ~ bc_tax + dLpop + dLgdp, data=datm, effect="twoways", index=c( "prov", "year"), model="within")
summary(m4.1)
coefs4.1 <- coeftest(m4.1, vcov=vcovHC(m4.1,type="HC0",cluster="group"))

dcoef <- coefs4.1[1,1]
dse <- coefs4.1[1,2]

cat.results$dcoef[j] <- dcoef
cat.results$dse[j] <- dse


m4.2 <- plm(dLemiss ~ bc_tax_dum  +  dLpop + dLgdp, data=datm, effect="twoways", index=c( "prov", "year"), model="within")
summary(m4.2)
coefs4.2 <- coeftest(m4.2, vcov=vcovHC(m4.2,type="HC0",cluster="group"))

dcoef.imp <- coefs4.2[1,1]
dse.imp <- coefs4.2[1,2]

cat.results$dcoef.imp[j] <- dcoef.imp
cat.results$dse.imp[j] <- dse.imp


######### with Lags and levels (eqbm correction) ##########

m4.3 <- plm(dLemiss ~ bc_tax + L1.dLemiss + L1.Lemiss + L1.Lpop + L1.Lgdp + dLpop + dLgdp, data=datm, effect="twoways", index=c( "prov", "year"), model="within")
summary(m4.3)
coefs4.3 <- coeftest(m4.3, vcov=vcovHC(m4.3,type="HC0",cluster="group"))

dcoef.L1 <- coefs4.3[1,1]
dse.L1 <- coefs4.3[1,2]

cat.results$dcoef.L1[j] <- dcoef.L1
cat.results$dse.L1[j] <- dse.L1


m4.4 <- plm(dLemiss ~ bc_tax_dum + L1.dLemiss + L1.Lemiss + L1.Lpop + L1.Lgdp + dLpop + dLgdp, data=datm, effect="twoways", index=c( "prov", "year"), model="within")
summary(m4.4)
coefs4.4 <- coeftest(m4.4, vcov=vcovHC(m4.4,type="HC0",cluster="group"))

dcoef.imp.L1 <- coefs4.4[1,1]
dse.imp.L1 <- coefs4.4[1,2]

cat.results$dcoef.imp.L1[j] <- dcoef.imp.L1
cat.results$dse.imp.L1[j] <- dse.imp.L1

###############################


##########################################################################################
################ Break Detection to identify treatment (for total and transport emissions) (Section 3)
############################################################################################

if (j %in% c(1, 3)){

  
  datm$id <- dummy(datm$prov.id)
  iddum <- dummy(datm$prov.id)
  yeardum <- dummy(datm$year)
  

  ymx <- cbind(datm$dLemiss_pc, datm$bc_tax, iddum[,-1], yeardum[,-1], datm$prov.id, datm$year, datm$prov)
  ymx.compl <- ymx[complete.cases(ymx),]

pval <- 0.025 #target significance p-value for selection

datm.comp <- datm[,c("prov", "prov.id","year", "Lemiss" , "L1.Lemiss" , "Lpop" , "Lgdp")]
datm.comp <- na.omit(datm.comp)

#### Break Detection to detect treatment
ispan2 <- isatpanel(data = datm.comp,
                   formula = Lemiss ~ L1.Lemiss + Lpop + Lgdp, 
                   index = c("prov","year"),
                   effect = "twoways",
                   fesis = TRUE,  t.pval=0.025, iis=TRUE)

  ################################################################
  ########## Extract the breakdates and regions from the panel
  #################################################################
  
 ispan2 <- ispan2$isatpanel.result
  timindex <- grep("time", ispan2$aux$mXnames)
  idindex <- seq(from=min(grep("id", ispan2$aux$mXnames)), to=min(timindex)-1, by=1)
  
  id.names <- ispan2$aux$mXnames[idindex]
  year.names <- ispan2$aux$mXnames[timindex]
  isdates <- isatdates(ispan2)

  iis.out <- ispan2$aux$mX[isdates$iis$date, c(id.names, year.names)]
  
  min.year <- as.numeric(substring(year.names[1], c(5) ))-1
  
  isdates$iis$id <- NA
  isdates$iis$year <- NA
  
  for (l in 1:NROW(iis.out)){

  pos <- which(iis.out[l,] != 0)  
 
  if ( length(pos)==0){
  id <- 1
  year <- min.year
  } else {
  nam <- colnames(iis.out)[pos]
  if (length(nam)>1){
    id <- substring(nam[1], c(3) )
    year <- as.numeric(substring(nam[2], c(5) ))
  } else {
    if ( length(grep("id", nam))==0){
    id <- 1
    year <- as.numeric(substring(nam[1], c(5) ))
    } else {
      id <- as.numeric(substring(nam[1], c(3) ))
      year <- min.year
    }
  }
  
  } #else null closed
  
  isdates$iis$id[l] <- id
  isdates$iis$year[l] <- year
  
  } #loop closed
 
  
  isdates$const <- NULL
  
  mxbreaknam <- ispan2$ISnames[!(ispan2$ISnames  %in% isdates$iis$breaks)]
  breakcoefs <- ispan2$mean.results[mxbreaknam,]
  mxbreaknam1 <- sapply(strsplit(mxbreaknam, "is"), "[", 2)
  id <- sapply(strsplit(mxbreaknam1, ".", fixed=T), "[", 1)
  time <- as.numeric(sapply(strsplit(mxbreaknam1, ".", fixed=T), "[", 2))
  year <- time
  
  names(breakcoefs) <- c( "coef" ,   "coef.se"  ,  "coef.t"   ,    "coef.p")
  breakcoefs$breaks <- mxbreaknam
  breakcoefs$id <- id
  breakcoefs$year <- year
  
  isdates$const <- breakcoefs
  isdates$const$year <- isdates$const$year

  ############## add province names
  isdates$iis$prov <- NA
  isdates$const$prov <- NA
  
  isdates$iis$prov <- isdates$iis$id 
  isdates$const$prov <- isdates$const$id 
  isdates
  
  ###scale by ar coefficient for equilibrium effects
  isdates$const$coef.eqbm <-  isdates$const$coef/(1-ispan2$coefficients[1])
  isdates$const$coef.eqbm.se <- NA
  

  for (l in 1:NROW(rownames(isdates$const))){
  
 
  vcov.rel <- vcov(ispan2)[c(rownames(isdates$const)[l], "L1.Lemiss"), c(rownames(isdates$const)[l], "L1.Lemiss")]
  coef.rel <- c(isdates$const$coef[l], ispan2$coefficients[1])

  delta.se <- deltamethod(~ x1/(1-x2), coef.rel, vcov.rel) 
  isdates$const$coef.eqbm.se[l] <- delta.se  
  
  }
  
  isdates$const$coef.eqbm.p <- 2*(1-pnorm(abs(isdates$const$coef.eqbm/isdates$const$coef.eqbm.se)))

  ######### percentage interpretation
  isdates$const$coef.pct.im <- 100*(exp(isdates$const$coef)-1)
  isdates$const$coef.pct.lr <- 100*(exp(isdates$const$coef.eqbm)-1)
  
  ###standard errors
  isdates$const$coef.pct.im.se <- NA
  isdates$const$coef.pct.lr.se <- NA
  
  for (l in 1:NROW(isdates$const)){
    isdates$const$coef.pct.im.se[l] <- deltamethod(~ 100*(exp(x1)-1), isdates$const$coef[l], isdates$const$coef.se[l]^2)
    isdates$const$coef.pct.lr.se[l] <- deltamethod(~ 100*(exp(x1)-1), isdates$const$coef.eqbm[l], isdates$const$coef.eqbm.se[l]^2)
  }


  #############

  pvals.pct.im <- 2*(1-pnorm(abs(isdates$const$coef.pct.im/isdates$const$coef.pct.im.se)))
  coef.star.pct.im <- stars.pval(pvals.pct.im)
  coef.pct.im <- paste(round(isdates$const$coef.pct.im),  "%", coef.star.pct.im, sep="")
  coef.pct.im.se <- paste( " (", round(isdates$const$coef.pct.im.se), "%)", sep="")
  paste(coef.pct.im, coef.pct.im.se, sep="")
  pvals.pct.lr <- 2*(1-pnorm(abs(isdates$const$coef.pct.lr/isdates$const$coef.pct.lr.se)))
  coef.star.pct.lr <- stars.pval(pvals.pct.lr)
  coef.pct.lr <- paste(round(isdates$const$coef.pct.lr),  "%", coef.star.pct.lr, sep="")
  coef.pct.lr.se <- paste( " (", round(isdates$const$coef.pct.lr.se), "%)", sep="")
  

  ###########add approximate breakdate uncertainty
  source("uncertainty_functions.r")

  m <- 15 #maximum interval
  se.scaled <- ispan2$sigma2/(1-ispan2$coefficients[1]^2)
  breaks_scaled <- isdates$const$coef/sqrt(ispan2$sigma2)

  prob <- matrix(NA, NROW(isdates$const), 2*m+1)
  ci <- matrix(NA, NROW(isdates$const), 2)

  for (b in 1: NROW(isdates$const)){

  time <- isattime(m, abs(breaks_scaled[b]))
  prob[b,] <- t(time)

  cu.p <- matrix(NA, (length(time)+1)/2, 1) 
  for (j in 1:((length(time)+1)/2))
  {
    start <-  (length(time)+1)/2  
    cu.p[j,1] <- sum(time[((start-j+1):(start+j-1))])
  }
  
  thresh <- 0.95
  ci.v <- min(which(abs(cu.p)>thresh))
  ci.d <- ci.v - 1
  cu.p[ci.v]
  
  ci[b,1] <- ci.d
  ci[b,2] <- cu.p[ci.v]
  
  }

  ###############
  
  isdates$const$time.95ci <- ci[,1]
  out.tab <- data.frame(matrix(NA, ncol=3, nrow=4+NROW(isdates$const)))
  colnames(out.tab) <- c("Variable", "M1", "Eqbm")
  out.tab$Variable <- c("logEmiss.L1", "logPop", "logGDP", "Breaks:", paste(isdates$const$prov, isdates$const$year, "+-",isdates$const$time.95ci,  sep=" "))
  
  out.tab$M1[1:3] <- paste(round(ispan2$mean.results$coef[1:3], 3), stars.pval(ispan2$mean.results$`p-value`[1:3]),  " (", round(ispan2$mean.results$std.error[1:3], 3), ")", sep="")
  out.tab$M1[5:NROW(out.tab)] <- paste(round(isdates$const$coef, 3), stars.pval(isdates$const$coef.p),  " (", round(isdates$const$coef.se, 3), ")", sep="")
  out.tab$Eqbm[5:NROW(out.tab)] <- paste(round(isdates$const$coef.eqbm, 3), stars.pval(isdates$const$coef.eqbm.p),  " (", round(isdates$const$coef.eqbm.se, 3), ")", sep="")
  
  lev_name_ispan <- paste("./tables/Table_5_breaks_", cat.j, "_drop_qa_", drop_ab_qc, ".doc", sep="")
  htmlTable(out.tab)
  write.table(htmlTable(out.tab),file=lev_name_ispan)
  
 
  ##################### Plot (negative) breaks with counter-factual
  
  isdates.neg <- isdates$const[isdates$const$coef < 0,]
  datm.rel <- datm[(datm$prov %in% unique(isdates.neg$prov)),]
  rel.prov <- unique(isdates.neg$prov)
  
  nonrel.prov <- unique(datm$prov[!(datm$prov %in% unique(isdates.neg$prov))])
  datm.nonrel <- datm[datm$prov %in% nonrel.prov,]
  
  nnonrel.prov <- NROW(nonrel.prov)
  nrelprov <- NROW(rel.prov)

  n <- nrelprov
  qual_col_pals = brewer.pal.info[brewer.pal.info$category == 'qual',]
  col_vector = unlist(mapply(brewer.pal, qual_col_pals$maxcolors, rownames(qual_col_pals)))
  pie(rep(1,n), col=sample(col_vector, n))
  col_fun <- colorRampPalette(brewer.pal(10, "Paired"))
  
  col_vector <- col_fun(nrelprov)
  prov_cols <- col_vector
  
  prov_cols <- c("#377eb8", "#ff7f00", "#984ea3")
  
  range <- 35
  int <- range/(nnonrel.prov-1)
  
  colvals <- round(seq(from=40, to=75, by=int))
  prov_cols.nonrel <- paste("gray", colvals, sep="")
  
  
  prov.m <- rel.prov[1]
  reldat <- datm.rel[datm.rel$prov==prov.m,]
  
  relprov.id <- unique(datm.rel$prov.id[datm.rel$prov %in% prov.m])
  relidvar <- paste("id", prov.m, sep="")
  

  rel.x <- ispan2$aux$mX[ispan2$aux$mX[,relidvar]==1,]
  rel.break <- rownames(isdates.neg[isdates.neg$id==prov.m,])
  rel.time <- isdates.neg$year[isdates.neg$id==prov.m] - 1
  min.relyear <- which(reldat$year==rel.time)
  
  # Predict Counterfactual
  pred.cf <- rep(NA, 26)
  pred.cf.upper <- rep(NA, 26)
  pred.cf.lower <- rep(NA, 26)
  pred.cf[min.relyear-1] <- reldat$Lemiss[min.relyear]
  pred.cf[min.relyear] <- rel.x[min.relyear,] %*% ispan2$coefficients - isdates.neg$coef[isdates.neg$id==prov.m]*rel.x[min.relyear,rel.break]
  
  pred.cf.upper[min.relyear-1] <- reldat$Lemiss[min.relyear]
  pred.cf.upper[min.relyear] <- rel.x[min.relyear,] %*% ispan2$coefficients - (isdates.neg$coef[isdates.neg$id==prov.m]+1.96*isdates.neg$coef.se[isdates.neg$id==prov.m])*rel.x[min.relyear,rel.break]
  
  pred.cf.lower[min.relyear-1] <- reldat$Lemiss[min.relyear]
  pred.cf.lower[min.relyear] <- rel.x[min.relyear,] %*% ispan2$coefficients - (isdates.neg$coef[isdates.neg$id==prov.m]-1.96*isdates.neg$coef.se[isdates.neg$id==prov.m])*rel.x[min.relyear,rel.break]
  
  
  for (l in (min.relyear+1): 26){
    
  pred.cf[l] <- pred.cf[l-1]*ispan2$coefficients[1] + rel.x[l,c(2:NCOL(rel.x))] %*% ispan2$coefficients[c(2:NCOL(rel.x))] - isdates.neg$coef[isdates.neg$id==prov.m]*rel.x[l,rel.break]
  
  pred.cf.upper[l] <- pred.cf.upper[l-1]*ispan2$coefficients[1] + rel.x[l,c(2:NCOL(rel.x))] %*% ispan2$coefficients[c(2:NCOL(rel.x))] - (isdates.neg$coef[isdates.neg$id==prov.m]+1.96*isdates.neg$coef.se[isdates.neg$id==prov.m])*rel.x[l,rel.break]
  pred.cf.lower[l] <- pred.cf.lower[l-1]*ispan2$coefficients[1] + rel.x[l,c(2:NCOL(rel.x))] %*% ispan2$coefficients[c(2:NCOL(rel.x))] - (isdates.neg$coef[isdates.neg$id==prov.m]-1.96*isdates.neg$coef.se[isdates.neg$id==prov.m])*rel.x[l,rel.break]
  

  }
  
  
  reldat$emiss.cf <-  reldat$emiss
  reldat$emiss.cf <- NA
  reldat$emiss.cf[2:27] <- exp(pred.cf)
  
  reldat$emiss.cf.upper <- NA
  reldat$emiss.cf.upper[2:27] <- exp(pred.cf.upper)
  
  reldat$emiss.cf.lower <- NA
  reldat$emiss.cf.lower[2:27] <- exp(pred.cf.lower)
  

  rel.year <- isdates.neg$year[isdates.neg$prov == prov.m]

  axloc <- c(1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000)
  axlabs <- c("1,000", "2,000", "5,000","10,000", "20,000", "50,000", "100,000", "200,000")
  
  
  isatname.pdf <- paste("./figures/Figure_9_breaks_", cat.j, ".pdf", sep="")
  isatname.png <- paste("./figures/Figure_9_breaks_", cat.j, ".png", sep="")
  

  save <- TRUE
  if (save==TRUE){
    # pdf(pc_name, width=9, height=7) 
    
    pdf(isatname.pdf,width=8.5,height=8)
    a<-dev.cur()
    png(isatname.png,width=1000,height=600)
    dev.control("enable")
    
  }
  
  
  plot(reldat$year[reldat$prov==prov.m], reldat$emiss[reldat$prov==prov.m], type="l", lwd=2.3, ylim=c(1000, 200000), yaxt="n", log="y", xlab="", ylab="CO2 Emissions, kt", xlim=c(1990, 2017), main="Detected Treatment Breaks in CO2 Emissions (Diff-in-Diff Specification)", col=prov_cols[1])  
  lines(reldat$year[reldat$prov==prov.m], reldat$emiss.cf[reldat$prov==prov.m], lty=2, col=prov_cols[1], lwd=1.8)
  axis(2, labels=axlabs, at=axloc)
  
  segments(x0=isdates.neg$year[isdates.neg$prov==prov.m]-1,
           lty=1, lwd=1.5,
           y0=reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)]-0.1*reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)],
           y1=reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)]+0.1*reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)], col=prov_cols[1])
  text(label=prov.m, x=2017, y=reldat$emiss[NROW(reldat)], col=prov_cols[1])
  text(label=paste( round(isdates.neg$coef[isdates.neg$prov==prov.m],2), " (", round(isdates.neg$coef.se[isdates.neg$prov==prov.m],2), ")", sep=""), 
       x = isdates.neg$year[isdates.neg$prov==prov.m]-1,
       y=reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)]+0.2*reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)], col=prov_cols[1])
  text(label=isdates.neg$year[isdates.neg$prov==prov.m], 
       x = isdates.neg$year[isdates.neg$prov==prov.m]-1,
       y=reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)]-0.2*reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)], col=prov_cols[1])
  

  abline(v=2007, lty=3, col=tax_col, lwd=0.9)
  text(x = 2009.7, y=2000, lab="BC Carbon Tax", col=tax_col)

  
  for (k in 1: NROW(nonrel.prov)){
    

    prov.m <- nonrel.prov[k]
    reldat <- datm.nonrel[datm.nonrel$prov==prov.m,]
    
    lines(datm.nonrel$year[datm.nonrel$prov==prov.m], datm.nonrel$emiss[datm.nonrel$prov==prov.m], type="l", col=prov_cols.nonrel[k], lwd=0.85)  
    text(label=prov.m, x=2017, y=reldat$emiss[NROW(reldat)], col=prov_cols.nonrel[k])
    
    
  }
  
  
  
  for (m in 2: NROW(rel.prov)){
    
    prov.m <- rel.prov[m]
    print(prov.m)
    reldat <- datm.rel[datm.rel$prov==prov.m,]
    
    
    
    relprov.id <- unique(datm.rel$prov.id[datm.rel$prov %in% prov.m])

    relidvar <- paste("id", prov.m, sep="")
     

    rel.x <- ispan2$aux$mX[ispan2$aux$mX[,relidvar]==1,]
    rel.break <- rownames(isdates.neg[isdates.neg$id==prov.m,])
    rel.time <- isdates.neg$year[isdates.neg$id==prov.m] - 1
    
    
    min.relyear <- which(reldat$year==rel.time)

    pred.cf <- rep(NA, 26)
    pred.cf[min.relyear-1] <- reldat$Lemiss[min.relyear]
    pred.cf[min.relyear] <- rel.x[min.relyear,] %*% ispan2$coefficients - isdates.neg$coef[isdates.neg$id==prov.m]*rel.x[min.relyear,rel.break]
    
    for (l in (min.relyear+1): 26){
      
      pred.cf[l] <- pred.cf[l-1]*ispan2$coefficients[1] + rel.x[l,c(2:NCOL(rel.x))] %*% ispan2$coefficients[c(2:NCOL(rel.x))] - isdates.neg$coef[isdates.neg$id==prov.m]*rel.x[l,rel.break]
      
      
    }

    reldat$emiss.cf <-  reldat$emiss
    reldat$emiss.cf <- NA
    reldat$emiss.cf[2:27] <- exp(pred.cf)
    
    rel.year <- isdates.neg$year[isdates.neg$prov == prov.m]
    lines(reldat$year[reldat$prov==prov.m], reldat$emiss[reldat$prov==prov.m], type="l", col=prov_cols[m], lwd=2.3 )  
    lines(reldat$year[reldat$prov==prov.m], reldat$emiss.cf[reldat$prov==prov.m], lty=4, col=prov_cols[m], lwd=1.8)
    
    segments(x0=isdates.neg$year[isdates.neg$prov==prov.m]-1,
             lty=1, lwd=1.5,
             y0=reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)]-0.1*reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)],
             y1=reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)]+0.1*reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)], col=prov_cols[m])
    text(label=prov.m, x=2017, y=reldat$emiss[NROW(reldat)], col=prov_cols[m])
    text(label=paste( round(isdates.neg$coef[isdates.neg$prov==prov.m],2), " (", round(isdates.neg$coef.se[isdates.neg$prov==prov.m],2), ")", sep=""), 
         x = isdates.neg$year[isdates.neg$prov==prov.m]-1,
         y=reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)]+0.2*reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)], col=prov_cols[m])
    text(label=isdates.neg$year[isdates.neg$prov==prov.m], 
         x = isdates.neg$year[isdates.neg$prov==prov.m]-1,
         y=reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)]-0.2*reldat$emiss[ reldat$year %in% (isdates.neg$year[isdates.neg$prov==prov.m]-1)], col=prov_cols[m])
    
    
  }
  
  if(save){
    dev.copy(which=a)
    
    dev.off()
    dev.off()
  }
  ###################################################
  
  
} #Break Detection loop closed



#########################
########Generate Plots:

avgyear <- 2008
scale <- TRUE
percent <- TRUE

if (percent){
  datm <- ddply(datm, c("prov"), transform, emiss_sc = scale(emiss, center=FALSE, scale=mean(emiss[year<avgyear])) )
  datm$emiss_sc <- (datm$emiss_sc - 1)*100  

  } else {
  datm <- ddply(datm, c("prov"), transform, emiss_sc = scale(emiss, center=mean(emiss[year<avgyear]), scale=sd(emiss[year<avgyear]))  ) 
}


datm.rest <- datm[which(datm$prov!="bc"),]
can.mean <- aggregate(datm.rest$emiss_sc, list(datm.rest$year), mean, na.rm=TRUE)
can.sd <- aggregate(datm.rest$emiss_sc, list(datm.rest$year), sd, na.rm=TRUE)

can.mean <- data.frame(cbind(can.mean, can.sd[,2]))
names(can.mean) <- c("year", "emiss_sc", "sd.emiss_sc")
can.mean$se.emiss_sc <- can.mean$sd.emiss_sc/sqrt(nprov-1)


pc_name <- paste("./figures/Fig_1_2_emiss_", cat.j,  "_drop_qa_", drop_ab_qc,".pdf", sep="")
png_name <- paste("./figures/Fig_1_2_emiss_", cat.j,  "_drop_qa_", drop_ab_qc,".png", sep="")


main <- paste(cat.j,  " Emissions in BC and Rest of Canada", sep="")


col.is.ci <- c(33,113,181)/255
col.ols.ci <- c(215,48,31)/255

col.is.ci.a <- rgb(col.is.ci[1], col.is.ci[2], col.is.ci[3],0.7)
col.ols.ci.a <- rgb(col.ols.ci[1], col.ols.ci[2], col.ols.ci[3],0.7)

col.is.line <- "#08519c"
col.ols.line <- "#d7301f"

col.true <- "#fd8d3c"
col.outl <- "#e31a1c"
col.outl.is <- "#225ea8"

if (percent)
{
  ylims <- c( max(min(datm$emiss_sc, na.rm=TRUE)*1.1, -150), min(max(datm$emiss_sc,na.rm=TRUE)*1.1, 150))
  ylabs <- "Percentage Change in Emissions"
  # min(datm$emiss_sc)*1.1
  # max(datm$emiss_sc)*1.1
  
} else{
  ylims <- c(-3.3, 3.3)  
  ylabs <- "Emissions, SD"
}
start.plot <- 1
end.plot <- 27


if (cat.j=="Electricity"){
  start.plot <- 2
  end.plot <- 24 
#  ylims <- c(-3.3, 3.3)
}
int.plot <- c(start.plot:end.plot)


###other cols
colvals <- seq(from=45, to=85, by=5)

prov_cols <- paste("gray", colvals, sep="")

tax_col <- "#7570b3"
null_col <- "#ff7f00"

save <- TRUE
if (save==TRUE){
 # pdf(pc_name, width=9, height=7) 
  pdf(pc_name,width=9,height=7)
  a<-dev.cur()
  png(png_name,width=1200,height=800)
  dev.control("enable")
  
  
}

plot(can.mean$year[int.plot], can.mean$emiss_sc[int.plot], col=col.is.line, lwd=4,  type="l", ylim=ylims, xlim=c(1990, 2016), xlab="Year", ylab=ylabs, main=main)
polygon(c(can.mean$year[int.plot], rev(can.mean$year[int.plot])), c( (can.mean$emiss_sc[int.plot]+2*can.mean$se.emiss_sc[int.plot] ), rev((can.mean$emiss_sc[int.plot]-2*can.mean$se.emiss_sc[int.plot] ))),
        col = col.is.ci.a, border = NA)

abline(v=2007, lty=2, col=tax_col, lwd=2)
#text(x = 2009.9, y=3.2, lab="BC Carbon Tax", col=tax_col)
abline(h=0, lty=1, col=null_col, lwd=1)

for (i in nprov:1){
  
  if (i == 2){
    lines(datm$year[datm$prov.id==i][int.plot], datm$emiss_sc[datm$prov.id==i][int.plot], col=col.ols.line, lwd=4)
    if (cat.j=="Electricity"){
      text(x=2014.5, y=datm$emiss_sc[datm$prov.id==i][int.plot[NROW(int.plot)]]+0.1, lab=paste(unique(datm$prov[datm$prov.id==i])), col=col.ols.line)
    } else {
      text(x=2016.5, y=datm$emiss_sc[datm$prov.id==i][int.plot[NROW(int.plot)]]+0.1, lab=paste(unique(datm$prov[datm$prov.id==i])), col=col.ols.line)
      
    }
    
      
    
   }  else{
     
    
       lines(datm$year[datm$prov.id==i][int.plot], datm$emiss_sc[datm$prov.id==i][int.plot], col=prov_cols[i-2])
       if (cat.j=="Electricity"){
         text(x=2014.5, y=datm$emiss_sc[datm$prov.id==i][int.plot[NROW(int.plot)]], lab=paste(unique(datm$prov[datm$prov.id==i])), col=prov_cols[i-2])
       } else {
         text(x=2016.5, y=datm$emiss_sc[datm$prov.id==i][int.plot[NROW(int.plot)]]+0.1, lab=paste(unique(datm$prov[datm$prov.id==i])), col=prov_cols[i-2])
         
       }
       
       
       
  }
  
}

if (percent){
  
  legend(y=ylims[2]*0.9, x=1992, c("BC", "Rest of Canada (Average)", "Other provinces"), col=c(col.ols.line , col.is.line, "gray45"), lty=c(1,1, 1), lwd=c(2,2, 1))
  
  if (cat.j=="Electricity"){
  text(x = 2009.3, y=ylims[2]*0.9, lab="BC Carbon Tax", col=tax_col)
  text(x=2014.8, y=can.mean$emiss_sc[int.plot[NROW(int.plot)]]-(ylims[2]-ylims[1])/75, lab="Rest of", col=col.is.line)
  text(x=2014.8, y=can.mean$emiss_sc[int.plot[NROW(int.plot)]]-4*(ylims[2]-ylims[1])/75, lab="CAN Avg.", col=col.is.line)
  } else {
  text(x = 2009.3, y=ylims[2]*0.9, lab="BC Carbon Tax", col=tax_col)
  text(x=2015.8, y=can.mean$emiss_sc[int.plot[NROW(int.plot)]]-(ylims[2]-ylims[1])/75, lab="Rest of", col=col.is.line)
  text(x=2015.8, y=can.mean$emiss_sc[int.plot[NROW(int.plot)]]-4*(ylims[2]-ylims[1])/75, lab="CAN Avg.", col=col.is.line)
  }
  
  
} else {
  legend(y=1.9, x=1992, c("BC", "Rest of Canada (Average)", "Other provinces"), col=c(col.ols.line , col.is.line, "gray45"), lty=c(1,1, 1), lwd=c(2,2, 1))
  text(x = 2009.3, y=3.2, lab="BC Carbon Tax", col=tax_col)
  text(x=2015.8, y=can.mean$emiss_sc[int.plot[NROW(int.plot)]]+0.5, lab="Rest of", col=col.is.line)
  text(x=2015.8, y=can.mean$emiss_sc[int.plot[NROW(int.plot)]]+0.2, lab="CAN Avg.", col=col.is.line)
}



if(save){
  dev.copy(which=a)
  
  dev.off()
  dev.off()
}







} ### industry loop closed


save.image("BCtaxrev_v2.RData") #Store the Rdata file.


################################################
######################## Create Tables and Figures  #######

  relcats <- c("TOTAL", "Stationary Combustion Sources", "Transport", "Fugitive Sources", "AGRICULTURE",  "INDUSTRIAL PROCESSES AND PRODUCT USE", "WASTE")
  
  
  cat.results$cat.lab <- NA
  cat.results$cat.lab[cat.results$cat=="co2.TOTAL"] <- "Total"
  cat.results$cat.lab[cat.results$cat=="co2.Stationary Combustion Sources"] <- "statEnergy"
  cat.results$cat.lab[cat.results$cat=="co2.Transport"] <- "Transp"
  cat.results$cat.lab[cat.results$cat=="co2.Fugitive Sources"] <- "Fugit"
  cat.results$cat.lab[cat.results$cat=="co2.AGRICULTURE"] <- "Agric"
  cat.results$cat.lab[cat.results$cat=="co2.INDUSTRIAL PROCESSES AND PRODUCT USE"] <- "Indust"
  cat.results$cat.lab[cat.results$cat=="co2.WASTE"] <- "Waste"
  
  

cat.results$lci.L1.eqbm.upper <- cat.results$lcoef.L1+abs(qnorm(0.025))*cat.results$lse.L1
cat.results$lci.L1.eqbm.lower <- cat.results$lcoef.L1-abs(qnorm(0.025))*cat.results$lse.L1

cat.results$lci.L1.eqbm.upper99 <- cat.results$lcoef.L1+abs(qnorm(0.005))*cat.results$lse.L1
cat.results$lci.L1.eqbm.lower99 <- cat.results$lcoef.L1-abs(qnorm(0.005))*cat.results$lse.L1


##############################
############ Write Results Tables
####################################

################################
#############  Table 1
relrows <- c("Oth Mean", "Oth SD", "oth Max", "Oth Min", "BC Mean", "BC SD", "BC Max", "BC Min")
relcols <- c("cat", cat.results$cat.lab, "Population", "GDP")

sumdat <- data.frame(matrix(NA, nrow=length(relrows), ncol=length(relcols)))
colnames(sumdat) <- relcols
rownames(sumdat)
sumdat[,1] <- relrows

for (i in 1: length(dat.list)){
  

 rellist <-  dat.list[[i]]
 
 sumdat[1,i+1] <- mean(rellist$emiss[rellist$prov!="bc"])
 sumdat[2,i+1] <- sd(rellist$emiss[rellist$prov!="bc"]) 
 sumdat[3,i+1] <- max(rellist$emiss[rellist$prov!="bc"])  
 sumdat[4,i+1] <- min(rellist$emiss[rellist$prov!="bc"])
 
 sumdat[1,NCOL(sumdat)] <- mean(rellist$gdp_marketpr[rellist$prov!="bc"])
 sumdat[2,NCOL(sumdat)] <- sd(rellist$gdp_marketpr[rellist$prov!="bc"])
 sumdat[3,NCOL(sumdat)] <- max(rellist$gdp_marketpr[rellist$prov!="bc"])
 sumdat[4,NCOL(sumdat)] <- min(rellist$gdp_marketpr[rellist$prov!="bc"])
 
 sumdat[1,NCOL(sumdat)-1] <- mean(rellist$pop[rellist$prov!="bc"])
 sumdat[2,NCOL(sumdat)-1] <- sd(rellist$pop[rellist$prov!="bc"])
 sumdat[3,NCOL(sumdat)-1] <- max(rellist$pop[rellist$prov!="bc"])
 sumdat[4,NCOL(sumdat)-1] <- min(rellist$pop[rellist$prov!="bc"])
 
 sumdat[5,i+1] <- mean(rellist$emiss[rellist$prov=="bc"])
 sumdat[6,i+1] <- sd(rellist$emiss[rellist$prov=="bc"]) 
 sumdat[7,i+1] <- max(rellist$emiss[rellist$prov=="bc"])  
 sumdat[8,i+1] <- min(rellist$emiss[rellist$prov=="bc"])
 
 sumdat[5,NCOL(sumdat)] <- mean(rellist$gdp_marketpr[rellist$prov=="bc"])
 sumdat[6,NCOL(sumdat)] <- sd(rellist$gdp_marketpr[rellist$prov=="bc"])
 sumdat[7,NCOL(sumdat)] <- max(rellist$gdp_marketpr[rellist$prov=="bc"])
 sumdat[8,NCOL(sumdat)] <- min(rellist$gdp_marketpr[rellist$prov=="bc"])
 
 sumdat[5,NCOL(sumdat)-1] <- mean(rellist$pop[rellist$prov=="bc"])
 sumdat[6,NCOL(sumdat)-1] <- sd(rellist$pop[rellist$prov=="bc"])
 sumdat[7,NCOL(sumdat)-1] <- max(rellist$pop[rellist$prov=="bc"])
 sumdat[8,NCOL(sumdat)-1] <- min(rellist$pop[rellist$prov=="bc"])
 
}

sumdat$Population <- sumdat$Population/1000000
sumdat$GDP <- sumdat$GDP/1000
sumdat[,2:7] <- sumdat[,2:7]/1000

sumdat[,2:NCOL(sumdat)] <- round(sumdat[,2:NCOL(sumdat)], 2)

sumdat.print <- rbind(sumdat[5:8,], sumdat[1:4,])

sumtabname <- paste("./tables/Table_1_ab_qc_",  drop_ab_qc, ".csv", sep="")
write.csv(sumdat.print, sumtabname, row.names=FALSE)

################################
############## Table 2
###############################

lev_name <- paste("./tables/Table_2_ab_qc_",  drop_ab_qc, ".doc", sep="")

se.list <- list(sec.level.model.se.list[[1]][,2])
for (j in 2: ncat){
  se.list[[j]] <- sec.level.model.se.list[[j]][,2]       
}


p.list <- list(sec.level.model.se.list[[1]][,4])
for (j in 2: ncat){
  p.list[[j]] <- sec.level.model.se.list[[j]][,4]       
}



covar.labs <- c("Tax", "logEmiss.L1", "logPop", "logGDP")

tax.coef.eqbm <- cat.results$lcoef.L1
tax.coef.eqbm.se <- cat.results$lse.L1

eqbm.coef <- paste(round(tax.coef.eqbm, 3))

pvals <- 2*(1-pnorm(abs(cat.results$lcoef.L1/cat.results$lse.L1)))


coef.star <- stars.pval(pvals)
eqbm.coef <- paste(eqbm.coef, coef.star, sep="")
eqbm.se <- paste("(", round(tax.coef.eqbm.se, 3), ")", sep="")

########### add a line of exact percentage impact

#exact % impact
cat.results$pct_im <- 100*(exp(cat.results$lcoef.L1.imed)-1)
cat.results$pct_im.se <- NA
for (l in 1:NROW(cat.results)){
  cat.results$pct_im.se[l] <- deltamethod(~ 100*(exp(x1)-1), cat.results$lcoef.L1.imed[l], cat.results$lcoef.L1.imed.se[l]^2)
}

cat.results$pct_lr <- 100*(exp(cat.results$lcoef.L1)-1)
cat.results$pct_lr.se <- NA
for (l in 1:NROW(cat.results)){
  cat.results$pct_lr.se[l] <- deltamethod(~ 100*(exp(x1)-1), cat.results$lcoef.L1[l], cat.results$lse.L1[l]^2)
}
#######################################



#############


pvals.pct.im <- 2*(1-pnorm(abs(cat.results$pct_im/cat.results$pct_im.se)))
coef.star.pct.im <- stars.pval(pvals.pct.im)
coef.pct.im <- paste(round(cat.results$pct_im),  "%", coef.star.pct.im, sep="")
coef.pct.im.se <- paste( " (", round(cat.results$pct_im.se), "%)", sep="")


pvals.pct.lr <- 2*(1-pnorm(abs(cat.results$pct_lr/cat.results$pct_lr.se)))
coef.star.pct.lr <- stars.pval(pvals.pct.lr)
coef.pct.lr <- paste(round(cat.results$pct_lr),  "%", coef.star.pct.lr, sep="")
coef.pct.lr.se <- paste(" (", round(cat.results$pct_lr.se), "%)", sep="")



stargazer( sec.level.model.list, se=se.list, p=p.list, type="html", out=lev_name, column.labels = cat.results$cat.lab, covariate.labels=covar.labs,
           dep.var.labels="logEmiss", add.lines=list(c("Eqbm Tax Coef.", eqbm.coef), c("Eqbm Se", eqbm.se), c("Pct. Impact", coef.pct.im), c("Pct. Impact Se", coef.pct.im.se), c("Pct. Eqbm Impact", coef.pct.lr), c("Pct. Eqbm Impact Se", coef.pct.lr.se)), star.char = c(".", "*", "**", "***"),
           star.cutoffs = c(0.1, 0.05, 0.01, 0.001),
           notes = c(". p<0.1; * p<0.05; ** p<0.01; *** p<0.001"), table.layout = "=ldc-t-a-s-n", keep.stat=c("rsq", "f", "ll", "sigma2", "n"))



##################################
##### Table A2 (Supplemementary Material)

lev_name.lags <- paste("./tables/Table_A2_ab_qc_",  drop_ab_qc, "lags.doc", sep="")

##########
se.list.lags <- list(sec.level.model.lag.se.list[[1]][,2])
for (j in 2: ncat){
  se.list.lags[[j]] <- sec.level.model.lag.se.list[[j]][,2]       
}


p.list.lags <- list(sec.level.model.lag.se.list[[1]][,4])
for (j in 2: ncat){
  p.list.lags[[j]] <- sec.level.model.lag.se.list[[j]][,4]       
}


stargazer( sec.level.model.lag.list,  type="html", out=lev_name.lags, column.labels = cat.results$cat.lab, 
           dep.var.labels="logEmiss", star.char = c( "*", "**", "***"),
           star.cutoffs = c(0.05, 0.01, 0.001),
           notes = c(". p<0.1; * p<0.05; ** p<0.01; *** p<0.001"), table.layout = "=ldc-t-a-s-n", keep.stat=c("rsq", "f", "ll", "sigma2", "n"))


########################################
######### Table A3 (Supplementary)


sec.level.model.lag.indep.list[[j]] <- m5.2m.lagsindep
sec.level.model.lag.indep.se.list[[j]] <- coefs5.2.lags.indep



lev_name.lags.ind <- paste("./tables/Table_A3_ab_qc_",  drop_ab_qc, "_lags_indep.doc", sep="")

stargazer( sec.level.model.lag.indep.list,  type="html", out=lev_name.lags.ind, column.labels = cat.results$cat.lab, 
           dep.var.labels="logEmiss", star.char = c( "*", "**", "***"),
           star.cutoffs = c(0.05, 0.01, 0.001),
           notes = c(". p<0.1; * p<0.05; ** p<0.01; *** p<0.001"), table.layout = "=ldc-t-a-s-n", keep.stat=c("rsq", "f", "ll", "sigma2", "n"))


################################
##############################

################
##### Table 3 

lev_name.dollar <- paste("./tables/Table_3_ab_qc_",  drop_ab_qc, ".doc", sep="")


se.dollar.list <- list(sec.level.dollar.model.se.list[[1]][,2])
for (j in 2: ncat){
  se.dollar.list[[j]] <- sec.level.dollar.model.se.list[[j]][,2]       
}


p.dollar.list <- list(sec.level.dollar.model.se.list[[1]][,4])
for (j in 2: ncat){
  p.dollar.list[[j]] <- sec.level.dollar.model.se.list[[j]][,4]       
}

stargazer( sec.level.dollar.model.list, se=se.dollar.list, p=p.dollar.list, type="html", out=lev_name.dollar, column.labels = cat.results$cat.lab, covariate.labels=covar.labs,
           dep.var.labels="logEmiss",  star.char = c(".", "*", "**", "***"),
           star.cutoffs = c(0.1, 0.05, 0.01, 0.001),
           notes = c(". p<0.1; * p<0.05; ** p<0.01; *** p<0.001"), table.layout = "=ldc-t-s-n", keep.stat=c("rsq", "f", "ll", "sigma2", "n"))



######################
########## Table B1 (Supplementary)

lev_name.pretrend <- paste("./tables/Table_B1_ab_qc_",  drop_ab_qc, ".doc", sep="")


se.pretrend.list <- list(pretrend.level.se.list[[1]][,2])
for (j in 2: ncat){
  se.pretrend.list[[j]] <- pretrend.level.se.list[[j]][,2]       
}


p.pretrend.list <- list(pretrend.level.se.list[[1]][,4])
for (j in 2: ncat){
  p.pretrend.list[[j]] <- pretrend.level.se.list[[j]][,4]       
}

covar.labs_pretrend <- c("Tax t-2", "Tax t-1", "Tax", "logEmiss.L1", "logPop", "logGDP")

stargazer( pretrend.level.model.list, se=se.pretrend.list, p=p.pretrend.list, type="html", out=lev_name.pretrend, column.labels = cat.results$cat.lab, covariate.labels=covar.labs_pretrend,
           dep.var.labels="logEmiss",  star.char = c(".", "*", "**", "***"),
           star.cutoffs = c(0.1, 0.05, 0.01, 0.001),
           notes = c(". p<0.1; * p<0.05; ** p<0.01; *** p<0.001"), table.layout = "=ldc-t-s-n", keep.stat=c("rsq", "f", "ll", "sigma2", "n"))

##########################
######## Synthetic Control: Table G2

write.table(htmlTable(synth.gap),file="./tables/Table_G2_synth_gap.doc") #Gap between synthetic and observed

###################################################
######################## Plots
##################################################

################## Compute share of emissions in BC
datbc <- datprov[datprov$prov=="bc",]
datbc$tot_comp <- rowSums(datbc[, 4:NCOL(datbc)])
datbc$share <- datbc[, 4:NCOL(datbc)]/datbc$tot_comp


col_fun <- colorRampPalette(brewer.pal(10, "Paired"))
col_vector <- rev(col_fun((NCOL(datbc$share)-1)))


save=TRUE

pdfname <- paste("./figures/Fig_2_bc_emiss_share_v1",   "_ab_qc", drop_ab_qc,  ".pdf", sep="")
pngname <- paste("./figures/Fig_2_bc_emiss_share_v1",   "_ab_qc", drop_ab_qc,  ".png", sep="")

if (save==TRUE){
  pdf(pdfname, width=9, height=7)
  a<-dev.cur()
  png(pngname ,width=1200,height=800)
  dev.control("enable")
}

par(mfrow=c(1,1))

plot(datbc$year, datbc$share[,1], type="l", xlim=c(min(datbc$year), max(datbc$year)+3), ylim=c(0, 0.55), col=col_vector[1], lwd=2, ylab="Share of BC CO2 Emissions", xlab="", main="Share of BC CO2 Emissions by Sector")
text(lab=names(datbc$share)[1], y=datbc$share[NROW(datbc),1], x=max(datbc$year)+2, col=col_vector[1])

for (j in 2:(NCOL(datbc$share)-1)){
  
  lines(datbc$year, datbc$share[,j], type="l", xlim=c(min(datbc$year), max(datbc$year)+3), col=col_vector[j], lwd=2)
  text(lab=names(datbc$share)[j], y=datbc$share[NROW(datbc),j], x=max(datbc$year)+2, col=col_vector[j])

}


if (save==TRUE){
  # dev.off()  
  dev.copy(which=a)
  
  dev.off()
  dev.off()    
}

datbc16 <- datbc[ datbc$year=="2016", ]


##################################################################
######################### Overall Plot with Immediate Effects and percentages


cat.results$lci.pct.im.upper <- cat.results$pct_im+abs(qnorm(0.025))*cat.results$pct_im.se
cat.results$lci.pct.im.lower <- cat.results$pct_im-abs(qnorm(0.025))*cat.results$pct_im.se

cat.results$lci.pct.im.upper99 <- cat.results$pct_im+abs(qnorm(0.005))*cat.results$pct_im.se
cat.results$lci.pct.im.lower99 <- cat.results$pct_im-abs(qnorm(0.005))*cat.results$pct_im.se

####order by effect size
cat.results$share <- 0
cat.results$share <- c(1, as.numeric(datbc16$share)[1:(ncat-1)])
   

  
step=0.33


cat.results <- cat.results[rev(order(cat.results$share)),]
cat.results$cat.num <- c(1, 0.6+seq(1, step*(NROW(cat.results)+2), by=step))


col.land.1<- c(189,189,189)/255
col.ci.oth <- rgb(col.land.1[1], col.land.1[2], col.land.1[3],1)

col.land.2<- c(82,82,82)/255
col.ci.tot <- rgb(col.land.2[1], col.land.2[2], col.land.2[3],1)

background <- c(254,224,210)/255
col.ci.back <- rgb(background[1], background[2], background[3],1)

widthtot <- 0.21
widthoth <- 0.11
offset95 <- 0.02
offset99 <- 0.010

save=TRUE

pdfname <- paste("./figures/Figure_4_pct_im_v1",   "_ab_qc", drop_ab_qc,   ".pdf", sep="")
pngname <- paste("./figures/Figure_4_pct_im_v1",   "_ab_qc", drop_ab_qc,  ".png", sep="")

if (save==TRUE){
  pdf(pdfname, width=11, height=8)
  a<-dev.cur()
  png(pngname ,width=1200,height=800)
  dev.control("enable")
}

layout(matrix(c(1, 1, 1, 2), nrow=4, byrow=TRUE))
#layout.show(n=4)

par(mar = c(0,0,0,0), oma = c(5,4,0.5,0.5), las =1)
par(mar = c(0,4,2,1)) #Add a space in the bottom axis


plot(cat.results$cat.num, pch="-", cex=0 , cat.results$pct_im, ylim=c(-20, 5), bty="n", xlim=c(0.8, max(cat.results$cat.num)+0.2), main="Estimated Level Impact of Carbon Tax (Diff-in Diff)", xaxt="n", ylab="Percentage Change in Emissions")

rect(xleft=0.66, xright=1.3, ytop=5, ybottom=-20, density = NULL, border = col.ci.back, col=col.ci.back)
segments(x0=cat.results$cat.num[1]-widthtot, x1=cat.results$cat.num[1]+widthtot, y0=cat.results$pct_im[1], lwd=1.5, col=col.ci.tot)
rect(xleft=cat.results$cat.num[1]-offset95, xright=cat.results$cat.num[1]+offset95, ytop=cat.results$lci.pct.im.upper[1], ybottom=cat.results$lci.pct.im.lower[1], density = NULL, border = col.ci.tot, col=col.ci.tot)
#rect(xleft=cat.results$cat.num[1]-offset99, xright=cat.results$cat.num[1]+offset99, ytop=cat.results$lci.L1.clus.upper99[1], ybottom=cat.results$lci.L1.clus.lower99[1], density = NULL, border = col.ci.tot, col=col.ci.tot)
arrows(as.numeric(cat.results$cat.num[1]), cat.results$lci.pct.im.lower99[1],as.numeric(cat.results$cat.num[1]), cat.results$lci.pct.im.upper99[1], length=0.14, angle=90, code=3, col=c(col.ci.tot), lwd=1.5)

arrows(as.numeric(cat.results$cat.num[2:NROW(cat.results$cat.num)]), cat.results$lci.pct.im.lower99[2:NROW(cat.results$cat.num)],as.numeric(cat.results$cat.num[2:NROW(cat.results$cat.num)]), cat.results$lci.pct.im.upper99[2:NROW(cat.results$cat.num)], length=0.08, angle=90, code=3, col=c( rep(col.ci.oth, NROW(cat.results)-1)), lwd=1.5)

segments(x0=cat.results$cat.num[2:NROW(cat.results$cat.num)]-widthoth, x1=cat.results$cat.num[2:NROW(cat.results$cat.num)]+widthoth, y0=cat.results$pct_im[2:NROW(cat.results$cat.num)], lwd=1.5,  col=col.ci.oth)
rect(xleft=cat.results$cat.num[2:NROW(cat.results$cat.num)]-offset95, xright=cat.results$cat.num[2:NROW(cat.results$cat.num)]+offset95, ytop=cat.results$lci.pct.im.upper[2:NROW(cat.results$cat.num)], ybottom=cat.results$lci.pct.im.lower[2:NROW(cat.results$cat.num)], density = NULL, border = col.ci.oth, col=col.ci.oth)

abline(h=0, lty=2, lwd=1, col="gray45")
text(x=cat.results$cat.num, y=2.5, labels=cat.results$cat.lab, cex=1.4)


par(mar = c(2,4,0,1))
plot(cat.results$cat.num[2:NROW(cat.results$cat.num)], cat.results$share[2:NROW(cat.results$cat.num)], ylim=c(0, 1), yaxt="n", cex=0, xlim=c(0.8, max(cat.results$cat.num)+0.2), bty="n", main="", xaxt="n", ylab="")

axis(1, at=cat.results$cat.num[2:NROW(cat.results$cat.num)], labels=cat.results$cat.lab[2:NROW(cat.results$cat.num)])
axis(2, pos=1.43)
text(x=0.5, label="Share of Emissions", srt=90)
segments(x0=1.43, x1=cat.results$cat.num[NROW(cat.results$cat.num)], y0=c(0.2, 0.4), lwd=0.7, lty=2,  col=col.ci.oth)


rect(xleft=cat.results$cat.num[2:NROW(cat.results$cat.num)]-0.11, xright=cat.results$cat.num[2:NROW(cat.results$cat.num)]+0.11, ytop=cat.results$share[2:NROW(cat.results$cat.num)], ybottom=0, density = NULL, border = col.ci.oth, col=col.ci.oth)


if (save==TRUE){
  # dev.off()  
  dev.copy(which=a)
  
  dev.off()
  dev.off()    
}


#######################################################################
######## Figure D1 (Supplementary)

pdfname <- paste("./figures/Figure_D1_lag_cluster",   "_ab_qc", drop_ab_qc,  ".pdf", sep="")
pngname <- paste("./figures/Figure_D1_lag_cluster",   "_ab_qc", drop_ab_qc,  ".png", sep="")

#save <- TRUE
if (save==TRUE){
  pdf(pdfname, width=11*1.2, height=8*1.2)
  a<-dev.cur()
  png(pngname,width=1200,height=800)
  dev.control("enable")
}



plot(cat.results$cat.num, pch="-", cex=0 , cat.results$lcoef.L1.imed, ylim=c(-0.3, 0.2), bty="n", xlim=c(0.8, max(cat.results$cat.num)+0.2), main="Estimated Level Impact of Carbon Tax (Diff-in Diff)", xaxt="n", ylab="Percentage Change in Emissions")
rect(xleft=0.66, xright=1.3, ytop=0.2, ybottom=-0.3, density = NULL, border = col.ci.back, col=col.ci.back)

segments(x0=cat.results$cat.num[1]-widthtot, x1=cat.results$cat.num[1]+widthtot, y0=cat.results$lcoef.L1.imed[1], lwd=1.5, col=col.ci.tot)
rect(xleft=cat.results$cat.num[1]-offset95, xright=cat.results$cat.num[1]+offset95, ytop=cat.results$lci.L1.clus.upper[1], ybottom=cat.results$lci.L1.clus.lower[1], density = NULL, border = col.ci.tot, col=col.ci.tot)

segments(x0=cat.results$cat.num[2:NROW(cat.results$cat.num)]-widthoth, x1=cat.results$cat.num[2:NROW(cat.results$cat.num)]+widthoth, y0=cat.results$lcoef.L1.imed[2:NROW(cat.results$cat.num)], lwd=1.5,  col=col.ci.oth)
rect(xleft=cat.results$cat.num[2:NROW(cat.results$cat.num)]-offset95, xright=cat.results$cat.num[2:NROW(cat.results$cat.num)]+offset95, ytop=cat.results$lci.L1.clus.upper[2:NROW(cat.results$cat.num)], ybottom=cat.results$lci.L1.clus.lower[2:NROW(cat.results$cat.num)], density = NULL, border = col.ci.oth, col=col.ci.oth)

abline(h=0, lty=2, lwd=1, col="gray45")
text(x=cat.results$cat.num, y=0.15, labels=cat.results$cat.lab, cex=1.4)

if (save==TRUE){
  dev.copy(which=a)
  
  dev.off()
  dev.off()    
}








