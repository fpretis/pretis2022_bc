clus.wild <- function (mod, dat, cluster, ci.level = 0.95, boot.reps = 1000, 
          report = TRUE, prog.bar = TRUE, output.replicates = FALSE) 
{
  if (min(class(dat) != "pdata.frame")) {
    cat("\n", "\n", "Note: auto-converting data to pdata.frame; first two variables MUST be group and time indices.", 
        "\n", "See ?pdata.frame and consider manually converting data to pdata.frame.", 
        "\n", "\n")
    dat <- pdata.frame(dat, index = colnames(dat)[1:2], row.names = F)
  }
  if (cluster == "group") {
    clust <- attr(mod$mod, "index")[, 1]
    clust.name <- colnames(attr(mod$mod, "index"))[1]
    clust.full <- attr(dat, "index")[, 1]
    used.idx <- which(rownames(dat) %in% rownames(mod$model))
    G <- length(unique(clust))
  }
  if (cluster == "time") {
    cat("\n", "\n", "Note: create new variable containing lag when clustering on time", 
        "\n")
    clust <- attr(mod$mod, "index")[, 2]
    clust.name <- colnames(attr(mod$mod, "index"))[2]
    clust.full <- attr(dat, "index")[, 2]
    used.idx <- which(rownames(dat) %in% rownames(mod$model))
    G <- length(unique(clust))
  }
  if (cluster != "group" & cluster != "time") {
    stop("invalid clustering variable; see help file")
  }
  "%w/o%" <- function(x, y) x[!x %in% y]
  form <- mod$formula
  variables <- all.vars(form)
  ind.variables.data <- all.vars(update(form, 1 ~ .))
  ind.variables <- rownames(summary(mod)$coefficients)
  count.v <- dim(mod$model)[2]
  ind.variables.full <- colnames(mod$model)[2:count.v]
  ind.variables.name <- ind.variables %w/o% "(Intercept)"
  se.clust <- sqrt(diag(vcovHC(mod, cluster = cluster)))
  beta.mod <- coefficients(mod)[ind.variables]
  w <- beta.mod/se.clust
  dat$dv.new[used.idx] <- mod$model[, 1]
  form.new <- update(form, dv.new ~ .)
  if (prog.bar == TRUE) {
    cat("Wild Cluster bootstrapping w/o imposing null...", 
        "\n")
  }
  boot.dat <- dat
  w.store <- matrix(data = NA, nrow = boot.reps, ncol = length(ind.variables))
  rep.store <- matrix(data = NA, nrow = boot.reps, ncol = length(beta.mod))
  colnames(rep.store) <- ind.variables
  resid <- residuals(mod)
  if (prog.bar == TRUE) {
    pb <- txtProgressBar(min = 0, max = boot.reps, initial = 0, 
                         style = 3)
  }
  for (i in 1:boot.reps) {
    if (prog.bar == TRUE) {
      setTxtProgressBar(pb, value = i)
    }
    weight <- c(1, -1)[rbinom(G, size = 1, prob = 0.5) + 
                         1][match(clust, unique(clust))]
    pseudo.resid <- resid * weight
    pseudo.dv <- predict(mod) + pseudo.resid
    boot.dat[used.idx, "dv.new"] <- pseudo.dv
    boot.mod.call <- mod$call
    boot.mod.call[[2]] <- quote(form.new)
    boot.mod.call[[3]] <- quote(boot.dat)
    boot.mod <- suppressWarnings(tryCatch(eval(boot.mod.call), 
                                          error = function(e) {
                                            return(NA)
                                          }))
    se.boot <- sqrt(diag(vcovHC(boot.mod, cluster = cluster)))
    beta.boot <- coefficients(boot.mod)[ind.variables]
    w.store[i, ] <- (beta.boot - beta.mod)/se.boot
    rep.store[i, ] <- beta.boot
  }
  if (prog.bar == TRUE) {
    close(pb)
  }
  comp.fun <- function(vec2, vec1) {
    as.numeric(vec1 > vec2)
  }
  if (length(ind.variables) == 1) {
    p.store.s <- matrix(as.double(abs(w)) > as.double(abs(w.store)), 
                        ncol = 1)
    crit.t <- quantile(abs(w.store), ci.level)
  }
  else {
    p.store.s <- t(apply(X = abs(w.store), FUN = comp.fun, 
                         MARGIN = 1, vec1 = abs(w)))
    crit.t <- apply(X = abs(w.store), MARGIN = 2, FUN = quantile, 
                    probs = ci.level)
  }
  p.store <- 1 - (colSums(p.store.s)/boot.reps)
  ci.lo <- beta.mod - crit.t * se.clust
  ci.hi <- beta.mod + crit.t * se.clust
  print.ci <- cbind(ind.variables, ci.lo, ci.hi)
  print.ci <- rbind(c("variable name", "CI lower", "CI higher"), 
                    print.ci)
  out.ci <- cbind(ci.lo, ci.hi)
  rownames(out.ci) <- ind.variables
  colnames(out.ci) <- c("CI lower", "CI higher")
  out <- matrix(p.store, ncol = 1)
  colnames(out) <- c("wild cluster BS p-value")
  rownames(out) <- ind.variables
  out.p <- cbind(ind.variables, round(out, 3))
  out.p <- rbind(c("variable name", "wild cluster BS p-value"), 
                 out.p)
  printmat <- function(m) {
    write.table(format(m, justify = "right"), row.names = F, 
                col.names = F, quote = F, sep = "   ")
  }
  if (report == T) {
    cat("\n", "\n", "Wild Cluster Bootstrapped p-values: ", 
        "\n", "\n")
    printmat(out.p)
    if (is.null(print.ci) == FALSE) {
      cat("\n", "Confidence Intervals (derived from bootstrapped t-statistics): ", 
          "\n", "\n")
      printmat(print.ci)
    }
    if (length(ind.variables.name) < length(ind.variables.full)) {
      cat("\n", "\n", "****", "Note: ", length(ind.variables.full) - 
            length(ind.variables.name), " variables were unidentified in the model and are not reported.", 
          "****", "\n", sep = "")
      cat("Variables not reported:", "\n", sep = "")
      cat(ind.variables.full[!ind.variables.full %in% ind.variables.name], 
          sep = ", ")
      cat("\n", "\n")
    }
  }
  out.list <- list()
  out.list[["p.values"]] <- out
  out.list[["ci"]] <- out.ci
  if (output.replicates == TRUE) {
    out.list[["replicates"]] <- rep.store
  }
  return(invisible(out.list))
}