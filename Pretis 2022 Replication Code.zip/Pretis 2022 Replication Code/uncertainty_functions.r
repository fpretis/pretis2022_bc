####This file compiles the uncertainty functions needed for sis


library(mvtnorm)

### Function for rotation
rotate <- function(x) t(apply(x, 2, rev))

### Function to extract matrices

mextrc <- function(x, p=0, k=0) #k=2*(plus minus), i.e. total range, and p is where it starts relative to the center, so k is the size, and p is the starting point
{
  
  mid <- NROW(x)/2
  out <- 2*k
  rotate <- function(x) t(apply(x, 2, rev))
  subx <- x[(mid+p-k):(mid+p-k+out+1),(mid+p-k):(mid+p-k+out+1)] 
  subx <- rotate(rotate(rotate(x)))[(mid+p-k):(mid+p-k+out+1),(mid+p-k):(mid+p-k+out+1)]
  output <- rotate(rotate(rotate(subx)))
  return(output)  
}

#####################################################

####### Function to compute SIS uncertainty

isattime <- function(m, delta, plot=FALSE)
{
  
#    m<-4
#    delta <- 1.214356
  
  
  #######################################
  
  lim <- 2*m
  sigma <- diag(2*m)
  a_lim <- m-1
  
  ########-----------Constructing general Up matrix
  
  up0 <- (matrix(NA, nrow=2*m, ncol=1))
  up <- (matrix(NA, nrow=2*m, ncol=(m)))
  
  ##vector to create up values
  #lim <- 10
  upg.a <- seq(1:lim)
  
  upg <- c(rev(upg.a*(-1)), upg.a)
  upg[(lim+1):(lim+m-1)]
  
  
  ###loop to generate
  for (j in 1:m){
    
    #T0 values
    up0[j, 1] <- delta/2*((m+1)-j)
    up0[j+m, 1] <- delta/2*j
    
    #Tp+m values
    ##loop over rows
    for (l in 1:(m+1))
    {
      #j is the column
      up[l,j] <- delta/2 *(((m+1)-l)-j)
      up[l+m-1, j] <- delta/2 * upg[(lim-1-j+l)]
    }
    
    
    
    
  }
  up
  up0
  
  up.tot <- cbind(up0, up)
 # up.tot
  
  
  
  
  
  
  
  #######------Constructing the general A Matrix
  
  #lim <- 2*m
  A <- matrix(0, nrow=lim, ncol=lim)
  for (i in 1:lim){
    
    A[i, 1:i] <- 1  
    
  }
  A
  Ar <- rotate(A)
  Arm <- (-1)*rotate(rotate(rotate(A)))
  Az <- matrix(0, nrow=lim, ncol=lim)
  Ag <- rbind(cbind(Az, Ar), cbind(Arm, Az))
  Ag
  Agb <- Ag*(-1)
  
  
  ###A0
  
  
  A0 <- mextrc(Agb, 0, a_lim )*(-1)
  A0gsigma <- A0%*%sigma%*%t(A0)
  p0 <- pmvnorm(mean=rep(0, NROW(A0gsigma)), sigma=A0gsigma, lower=rep(-Inf, NROW(A0gsigma)), upper=up.tot[,1] )[1]
  p0
  
  
  p_m <- matrix(NA, m, 1)
  #p_m[(NROW(p_m)+1)/2,1] <- p0
  
  ### up to m
  for (i in 1:m){
    
  ##  print("i")
  ##  print(i)
    
    Ai <- mextrc(Agb, i, a_lim )
   ## print(Ai)
    Aisigma <- Ai%*%sigma%*%t(Ai)
    pi <- pmvnorm(mean=rep(0, NROW(Aisigma)), sigma=Aisigma, lower=rep(-Inf, NROW(Aisigma)), upper=up.tot[,(i+1)] )[1]
 ##   print(pi)
    
    p_m[i,1] <- pi
   ## print(p_m)  
  }
  
  
  #p_m_rev <- rev(p_m)
  
  p.tot <- as.matrix(c(rev(p_m), p0, p_m))
  p.tot
  colSums(p.tot)

 x <- seq(from = -m, to=m, by=1)
 
 if (plot)
 {
   plot(x, p.tot, type='hist') 
 }
 
 
  return(p.tot)
  
#  k <- 2
#  sum(p.tot[((length(p.tot)+1)/2-k):((length(p.tot)+1)/2+k)])
  
  

  
}

#######################################################

###########################
##### CI Constructor
#x is output from isattime

isatci <- function(x, p=0.95){
  
ci <- matrix(NA, 1, 2)
cu.p <- matrix(NA, (length(x)+1)/2, 1) 
for (j in 1:((length(x)+1)/2))
{
  start <-  (length(x)+1)/2  
  cu.p[j,1] <- sum(x[((start-j+1):(start+j-1))])
}

thresh <- p
#ci.v <- which.min(abs(cu.p-thresh))
ci.v <- min(which(abs(cu.p)>thresh))
ci.d <- ci.v - 1
#ci.d <- (which.min(abs(cu.p-thresh))-1)/2
cu.p[ci.v]

ci[,1] <- ci.d
ci[,2] <- cu.p[ci.v]

colnames(ci) <- c("d", "p_k")

return(ci)

}



####################################
######### Simplified function for a CI from BP
###################################

bp.ci <- function(y = NULL, b=NULL, X= NULL,lambda = NULL, sigmasq=NULL, breaks = NULL, level = 0.95, parm = NULL, het.reg = FALSE, het.err = FALSE, vcov. = NULL, sandwich = TRUE) {
  
  require(strucchange)
  
  #breakpoints
  
  ##for testing  
  #   y <- ys
  #   X <- matrix(1, T, 1)
  #   lambda <- 3
  #   breaks <- 1
  #   b <- 50
  
  
  ###code
  
  T <- length(y)
  xs1 <- matrix(0, T, 1)
  xs1[b:T,1] <- 1
  resi <- y - lambda*xs1
  n <- T
  
  ##function code  
  
  
  a2 <- (1 - level)/2
  # if (!is.null(parm) & !is.null(breaks)) 
  #   warning("`parm' and `breaks' are both specified: `breaks' is used")
  # else if (!is.null(parm)) 
  #   breaks <- parm
  myfun <- function(x, level = 0.975, xi = 1, phi1 = 1, phi2 = 1) (pargmaxV(x, 
                                                                            xi = xi, phi1 = phi1, phi2 = phi2) - level)
  myprod <- function(delta, mat) as.vector(crossprod(delta, 
                                                     mat) %*% delta)
  
  #  bp <- breakpoints(object, breaks = breaks)$breakpoints
  bp <- b
  #   if (any(is.na(bp))) 
  #     stop("cannot compute confidence interval when `breaks = 0'")
  nbp <- length(bp)
  upper <- rep(0, nbp)
  lower <- rep(0, nbp)
  bp <- c(0, bp, n)
  res <- resi
  #res <- residuals(object, breaks = breaks)
  sigma1 <- sigma2 <- sigmasq
  #sigma1 <- sigma2 <- sum(res^2)/n
 
  Q1 <- Q2 <- crossprod(X)/n
  if (is.null(vcov.)) 
    Omega1 <- Omega2 <- sigma1 * Q1
  else {
    y.nb <- rowSums(X) + res
    fm <- lm(y.nb ~ 0 + X)
    if (sandwich) {
      Omega1 <- Omega2 <- n * crossprod(Q1, vcov.(fm)) %*% 
        Q1
    }
    else {
      Omega1 <- Omega2 <- vcov.(fm)
    }
  }
  xi <- 1
  X2 <- X[(bp[1] + 1):bp[2], , drop = FALSE]
  y2 <- y[(bp[1] + 1):bp[2]]
  fm2 <- lm(y2 ~ 0 + X2)
  beta2 <- coef(fm2)
  if (het.reg) 
    Q2 <- crossprod(X2)/nrow(X2)
  if (het.err) {
    sigma2 <- sum(residuals(fm2)^2)/nrow(X2)
    if (is.null(vcov.)) 
      Omega2 <- sigma2 * Q2
    else {
      if (sandwich) 
        Omega2 <- nrow(X2) * crossprod(Q2, vcov.(fm2)) %*% 
        Q2
      else Omega2 <- vcov.(fm2)
    }
  }
  for (i in 2:(nbp + 1)) {
    X1 <- X2
    y1 <- y2
    beta1 <- beta2
    sigma1 <- sigma2
    Q1 <- Q2
    Omega1 <- Omega2
    X2 <- X[(bp[i] + 1):bp[i + 1], , drop = FALSE]
    y2 <- y[(bp[i] + 1):bp[i + 1]]
    fm2 <- lm(y2 ~ 0 + X2)
    beta2 <- coef(fm2)
    delta <- lambda
    #  delta <- beta2 - beta1
    if (het.reg) 
      Q2 <- crossprod(X2)/nrow(X2)
    if (het.err) {
      sigma2 <- sum(residuals(fm2)^2)/nrow(X2)
      if (is.null(vcov.)) 
        Omega2 <- sigma2 * Q2
      else {
        if (sandwich) 
          Omega2 <- nrow(X2) * crossprod(Q2, vcov.(fm2)) %*% 
          Q2
        else Omega2 <- vcov.(fm2)
      }
    }
    Oprod1 <- myprod(delta, Omega1)
    Oprod2 <- myprod(delta, Omega2)
    Qprod1 <- myprod(delta, Q1)
    Qprod2 <- myprod(delta, Q2)
    if (het.reg) 
      xi <- Qprod2/Qprod1
    if (!is.null(vcov.)) 
      phi1 <- sqrt(Oprod1/Qprod1)
    else phi1 <- sqrt(sigma1)
    if (!is.null(vcov.)) 
      phi2 <- sqrt(Oprod2/Qprod2)
    else phi2 <- sqrt(sigma2)
    p0 <- pargmaxV(0, phi1 = phi1, phi2 = phi2, xi = xi)
    
    #pargmaxV
    
    
    if (is.nan(p0) || p0 < a2 || p0 > (1 - a2)) {
      warning(paste("Confidence interval", as.integer(i - 
                                                        1), "cannot be computed: P(argmax V <= 0) =", 
                    round(p0, digits = 4)))
      upper[i - 1] <- NA
      lower[i - 1] <- NA
    }
    else {
      ub <- lb <- 0
      while (pargmaxV(ub, phi1 = phi1, phi2 = phi2, xi = xi) < 
               (1 - a2)) ub <- ub + 1000
      while (pargmaxV(lb, phi1 = phi1, phi2 = phi2, xi = xi) > 
               a2) lb <- lb - 1000
      upper[i - 1] <- uniroot(myfun, c(0, ub), level = (1 - 
                                                          a2), xi = xi, phi1 = phi1, phi2 = phi2)$root
      lower[i - 1] <- uniroot(myfun, c(lb, 0), level = a2, 
                              xi = xi, phi1 = phi1, phi2 = phi2)$root
      upper[i - 1] <- upper[i - 1] * phi1^2/Qprod1
      lower[i - 1] <- lower[i - 1] * phi1^2/Qprod1
    }
  }
  bp <- bp[-c(1, nbp + 2)]
  bp <- cbind(bp - ceiling(upper), bp, bp - floor(lower))
  a2 <- round(a2 * 100, digits = 1)
  colnames(bp) <- c(paste(a2, "%"), "breakpoints", paste(100 - 
                                                           a2, "%"))
  rownames(bp) <- 1:nbp
  bp
  
  return(bp)
  
}


#################################################
#######################################################
### Function for variance consistency correction

isvarcor <- function(t.pval, sigma) {
  
  alpha <- t.pval
  sigmals <- sigma
  
  c <- abs(qnorm(alpha/2))
  
  psi <- pnorm(c) - pnorm(-c) 
  tau <- psi - 2*c*dnorm(c)
  
  xi_sq <- tau/psi
  xi_sq
  
  xi <- sqrt(xi_sq)
  corrxi <- 1/xi
  
  sigmacorr <- sigmals * corrxi
  
  object <- cbind(sigmacorr, corrxi)
  return(object)
}


