##############################################
################ Replication code (File B)
# Pretis (2022)
# "Does a carbon tax reduce CO2 emissions? Evidence from British Columbia"
# Environmental and Resource Economics, 83, 115-144
###############################################


###########
#### Code File B Replicates Gridded Emission Estimates
##########

rm(list=ls())


library(rgdal)
library(gets)
library(spdep)
library(raster)
library(plyr)
library(ncdf4)
library(raster)
library(maps)
library(reshape2)
library(ff)
library(spdep)
library(countrycode)
library(plm)
library(lfe)
library(stargazer)
library(gtools)
library(msm)
library(dummies)
library(maptools)
library(RColorBrewer)
library(rasterVis)
library(lattice)

###############


transp <- FALSE #TRUE if analyse transport emissions, FALSE if analysing aggregate emissions


setwd('C:/Users/fpretis/OneDrive - University of Victoria/Documents/Projects/BC carbon tax/code/Pretis 2022 Replication Code')

dat.m <- read.csv(paste("./data/spatial_data_transp_", transp, ".csv", sep=""))

dat.m$bc.tax <- 0 
dat.m$bc.tax[dat.m$year > 2007 & dat.m$bc==1] <- 1
sum(dat.m$bc.tax)

dat.m$P1.bc.tax <- 0 
dat.m$P1.bc.tax[dat.m$year > 2006 & dat.m$bc==1] <- 1
dat.m$P2.bc.tax <- 0 
dat.m$P2.bc.tax[dat.m$year > 2005 & dat.m$bc==1] <- 1
dat.m$P3.bc.tax <- 0 
dat.m$P3.bc.tax[dat.m$year > 2004 & dat.m$bc==1] <- 1
dat.m$P4.bc.tax <- 0 
dat.m$P4.bc.tax[dat.m$year > 2003 & dat.m$bc==1] <- 1


dat.m$L1.bc.tax <- 0 
dat.m$L1.bc.tax[dat.m$year > 2008 & dat.m$bc==1] <- 1
dat.m$L2.bc.tax <- 0 
dat.m$L2.bc.tax[dat.m$year > 2009 & dat.m$bc==1] <- 1
dat.m$L3.bc.tax <- 0 
dat.m$L3.bc.tax[dat.m$year > 2010 & dat.m$bc==1] <- 1
dat.m$L4.bc.tax <- 0 
dat.m$L4.bc.tax[dat.m$year > 2011 & dat.m$bc==1] <- 1



dat.m$bc.tax.dum <- 0 
dat.m$bc.tax.dum[dat.m$year ==2008 & dat.m$bc==1] <- 1


dat.m <- dat.m[order(dat.m$id, dat.m$year),]

lg <- function(x)c(NA, x[1:(length(x)-1)])
library(plyr)

dat.m <- ddply(dat.m, ~id, transform, L1.co2 = lg(co2))

dat.m <- ddply(dat.m, ~id, transform, L1.light = lg(light))

dat.m$lco2 <- log(dat.m$co2)
dat.m$L1.lco2 <- log(dat.m$L1.co2)
dat.m$dlco2 <- dat.m$lco2 - dat.m$L1.lco2

dat.m <- ddply(dat.m, ~id, transform, L1.dlco2 = lg(dlco2))

dat.m$light.adj <- dat.m$light + 1 # baseline adjustment to allow for log transforms
dat.m$L1.light.adj <- dat.m$L1.light + 1 # baseline adjustment to allow for log transforms

dat.m$llight <- log(dat.m$light.adj)
dat.m$L1.llight <- log(dat.m$L1.light.adj)

dat.m$dlight <- dat.m$light - dat.m$L1.light
dat.m$dllight <- dat.m$llight - dat.m$L1.llight

dat.m$prov <- NA
dat.m$prov[dat.m$bc==1] <- 1
dat.m$prov[dat.m$ab==1] <- 2
dat.m$prov[dat.m$sk==1] <- 3
dat.m$prov[dat.m$mb==1] <- 4
dat.m$prov[dat.m$on==1] <- 5
dat.m$prov[dat.m$qc==1] <- 6
dat.m$prov[dat.m$nb==1] <- 7
dat.m$prov[dat.m$nl==1] <- 8
dat.m$prov[dat.m$ns==1] <- 9
dat.m$prov[dat.m$pe==1] <- 10


NROW(dat.m[which(dat.m$prov==1),])
NROW(dat.m[which(dat.m$prov==2),])
NROW(dat.m[which(is.na(dat.m$prov)),])

dat.m.compl <- dat.m


m1 <- plm(lco2 ~ bc.tax +  L1.lco2, data=dat.m.compl, index=c("id", "year"), effect="twoways", model="within")
summary(m1)



####in levels
dat.m.compl$year.f <- as.factor(dat.m.compl$year)
dat.m.compl$prov.f <- as.factor(dat.m.compl$prov)
dat.m.compl$id.f <- as.factor(dat.m.compl$id)


##### Table 4, Model 1 (First column in each category)
est2 <- felm(lco2 ~ bc.tax  |  id.f + year.f  | 0 | id.f , data=dat.m.compl)
summary(est2)

##### Table 4, Model 2 (second column in each category)
est1 <- felm(lco2 ~ bc.tax  + L1.lco2 |  id.f + year.f  | 0 | prov.f , data=dat.m.compl)
summary(est1)



rel.est1 <- coefficients(est1)[1:2]
rel.vcov.est1 <- vcov(est1)[1:2, 1:2]

eqbm.est1 <- rel.est1[1]/(1-rel.est1[2])
eqbm.est1.se <- deltamethod(~ x1/(1-x2), rel.est1, rel.vcov.est1) 

##### Table 4, Model 4 (fourth column in each category)
est4 <- felm(dlco2 ~ bc.tax  |  id.f + year.f  | 0 | id.f , data=dat.m.compl)
summary(est4)


######################
######### Controlling for lights

##### Table 4, Model 3 (third column in each category)
est7 <- felm(lco2 ~ bc.tax  + L1.lco2 +  light |  id.f + year.f  | 0 | id.f , data=dat.m.compl)
summary(est7)

##### Table 4, Model 5 (fifth column in each category)
est8 <- felm(dlco2 ~ bc.tax + dllight  |  id.f + year.f  | 0 | id.f , data=dat.m.compl)
summary(est8)





tax.coef.eqbm <- eqbm.est1
tax.coef.eqbm.se <- eqbm.est1.se
eqbm.coef <- paste(round(tax.coef.eqbm, 3))
pvals <- 2*(1-pnorm(abs(tax.coef.eqbm/tax.coef.eqbm.se)))




coef.star <- stars.pval(pvals)
eqbm.coef <- paste(eqbm.coef, coef.star, sep="")
eqbm.se <- paste("(", round(tax.coef.eqbm.se, 3), ")", sep="")

lev_name <- paste("./tables/Table_4_aggregate.doc", sep="")
if (transp){
  lev_name <- paste("./tables/Table_4_transport.doc", sep="")  
}

stargazer( list(est2, est1, est7,  est4,  est8),  type="html", out=lev_name, covariate.labels = c("Tax", "logEmiss.L1", "Light", "dLight"),
           dep.var.labels=c("logEmiss", "dlog(Emiss)"), keep.stat=c("rsq", "ll", "sigma2", "n"), star.char = c(".", "*", "**", "***"),
           star.cutoffs = c(0.1, 0.05, 0.01, 0.001),
           notes = c(". p<0.1; * p<0.05; ** p<0.01; *** p<0.001"), table.layout = "=ldc-t-s-n")


######## individual interactions


dat.m.compl$id.f <- as.factor(dat.m.compl$id)

dat.m.compl$id.bc <- as.numeric(dat.m.compl$id.f)*dat.m.compl$bc
dat.m.compl$id.bc <- as.factor(dat.m.compl$id.bc)

dums <- dummy(dat.m.compl$id.bc)[,-1]
dums <- dums[,-NCOL(dums)]


dat.m.compl$iddum_bc <- dums
dat.m.compl$bc_id_tax <- dat.m.compl$iddum_bc*dat.m.compl$bc.tax

int_dum <- dat.m.compl$iddum_bc*dat.m.compl$bc.tax

dat.r <- dat.m.compl[,c("id", "year", "id.f", "prov.f", "year.f", "lco2", "dlco2", "bc.tax", "L1.lco2", "light", "llight")]
dat.r <- data.frame(dat.r, int_dum)

form1 <- paste(colnames(int_dum), collapse=" + " )
form <- paste("lco2 ~ bc.tax + L1.lco2 + light", form1, sep=" + ")


form.lfe <- paste(form, "|  id.f + year.f  | 0 | id.f", sep="")
form.lfe

form <- as.formula(form)
form.lfe <- as.formula(form.lfe)

est <- felm(form.lfe, data=dat.r[complete.cases(dat.r),])
summary(est)


m1 <- plm(form , data=dat.r, index=c("id", "year"), effect="twoways", model="within")
sum1 <- summary(m1)

coefficients(m1)
m1.t <- sum1$coefficients[3:NROW(sum1$coefficients),"t-value"]
hist(m1.t, breaks=40)
abline(v=c(-1.96, 1.96), lty=3, col="red")
count1 <- sum((abs(m1.t)>1.96))
prop1 <- count1/NROW(m1.t)

########
### extract estimates and covariances
vco <- vcov(m1)

coef.full <- sum1$coefficients["bc.tax",1]
v.full <- vco["bc.tax","bc.tax"]

coefs.int <- sum1$coefficients[colnames(int_dum)[1:(NCOL(int_dum)-1)],1]

v.int <- diag(vco[colnames(int_dum)[1:(NCOL(int_dum)-1)],colnames(int_dum)[1:(NCOL(int_dum)-1)]])
cov.int <- vco[colnames(int_dum)[1:(NCOL(int_dum)-1)], "bc.tax"]


coefs.joint <- coef.full + coefs.int
se.joint <- sqrt(v.full + v.int + 2*cov.int)
t.joint <- coefs.joint/se.joint
p.joint <- 2*(1-pnorm(abs(t.joint)))


########

rel.id <- unique(dat.m.compl$id[which(dat.m.compl$id.bc!=0)])
rel.id <- rel.id[-NROW(rel.id)] #drop last because drops out

dat.m.trim <- dat.m.compl[dat.m.compl$year==2009,]

rel.x <- dat.m.trim$x[which(dat.m.trim$id.bc!=0)]
rel.x <- rel.x[-NROW(rel.x)]


rel.y <- dat.m.trim$y[which(dat.m.trim$id.bc!=0)]
rel.y <- rel.y[-NROW(rel.y)]


dat.int <- data.frame(matrix(NA, nrow=NROW(coefs.joint), ncol=1))
names(dat.int) <- "id"
dat.int$id <- rel.id
dat.int$x <- rel.x
dat.int$y <- rel.y
dat.int$coefs.joint <- coefs.joint
dat.int$se.joint <- se.joint
dat.int$p.joint <- p.joint
dat.int$t.joint <- t.joint

##############
####### Bonferroni Type Correction

pval <- 0.05
testp <- dat.int$p.joint

testp.norm.ord <- testp[order( testp)]


n_bon <- NROW(testp)
j_bon <- seq(from=1, to=n_bon)

##modified bonferroni approach:
if (any(testp.norm.ord < j_bon*pval/n_bon)){
  prop_modbon <- 1
} else {
  prop_modbon <- 0
}

##############
cbind(testp.norm.ord, j_bon*pval/n_bon)
testp.norm.ord <  j_bon*pval/n_bon

#############



grid_b <- raster()

ex <- extent(grid_b)
str(ex)

ex@xmin <- -180
ex@xmax <- 180

ex@ymin <- -80
ex@ymax <- 80

grid <- raster(ex)


res(grid) <- 20
gridpolygon <- rasterToPolygons(grid)





longlat <- CRS('+proj=longlat +datum=WGS84 +no_defs +ellps=WGS84 +towgs84=0,0,0')
data(wrld_simpl)
wrld <- spTransform(wrld_simpl, longlat)



res(grid) <- 20
gridpolygon <- rasterToPolygons(grid)

###########gridlabels

####Y
y.vals_s <- c(seq(80, 20, -20))
y.vals_n <- c(seq(20, 80, 20))
#y.vals/labs <- c(y.vals_s, 0, y.vals_n )

ylabs_s <- paste(y.vals_s, "S", sep="")
ylabs_n <- paste(y.vals_n, "N", sep="")
y_labels <- c(ylabs_s, "0", ylabs_n)

y.vals <- c(seq(-80,80,20))

x.vals_w <- c(seq(160, 20, -20))
x.vals_e <- c(seq(20, 160, 20))

xlabs_w <- paste(x.vals_w, "W", sep="")
xlabs_e <- paste(x.vals_e, "E", sep="")
x_labels <- c(xlabs_w, "0", xlabs_e)

x.vals <- c(seq(-160,160,20))


####Y
y.vals_s <- c(seq(80, 20, -20))
y.vals_n <- c(seq(20, 80, 20))
#y.vals/labs <- c(y.vals_s, 0, y.vals_n )

ylabs_s <- paste(y.vals_s, "S", sep="")
ylabs_n <- paste(y.vals_n, "N", sep="")
y_labels <- c(ylabs_s, "0", ylabs_n)

y.vals <- c(seq(-80,80,20))

###X

x.vals_w <- c(seq(160, 20, -20))
x.vals_e <- c(seq(20, 160, 20))

xlabs_w <- paste(x.vals_w, "W", sep="")
xlabs_e <- paste(x.vals_e, "E", sep="")
x_labels <- c(xlabs_w, "0", xlabs_e)

x.vals <- c(seq(-160,160,20))

#colours

cols_a <- c("darkblue", "blue", "grey96", "orange", "darkred")
cols_b <- c("darkblue", "grey96","darkred")


###########################
########### Plot Individual Deviations


dat.m.bal.plot_year <- dat.int[,c('x', 'y', 't.joint')]
dat.rast <- rasterFromXYZ(dat.m.bal.plot_year)  #Convert first two columns as lon-lat and third as value                
cols_d <- c( "#08519c", "#4292c6", "#e0f3f8", "#fee0d2",  "#ff7f00", "#d73027")


breaks.p <- c(-100, -2.57, -1.96, 0, 1.96, 2.57, 100)
breaks.p_l <- seq(from=0, to=(length(breaks.p)-1))


break_labs_p <- paste("t=", c(breaks.p),sep="")
break_labs_p

break_labs_p[c(1, NROW(break_labs_p))] <- ""

colkey_p <- list(at=breaks.p_l, labels=list(at=breaks.p_l, labels=break_labs_p, cex=1.2), space="right")

pdf_name <- "./figures/Figure_6_emissions_signif.pdf"
png_name <- "./figures/Figure_6_emissions_signif.png"

if (transp){
  pdf_name <- "./figures/Figure_6_emissions_signif_transp.pdf"
  png_name <- "./figures/Figure_6_emissions_signif_transp.png"
}

pdf(pdf_name,width=9,height=7)
a<-dev.cur()
png(png_name,width=900,height=800)
dev.control("enable")

p.plot <- levelplot(dat.rast,  margin = FALSE, main=list(label="t-value for significant (local) tax effect", cex=2.0),  ylim=c(45,70), xlim=c(-145, -105),  col.regions=cols_d, at=breaks.p, colorkey=colkey_p) 
p.plot

dev.copy(which=a)

dev.off()
dev.off()



